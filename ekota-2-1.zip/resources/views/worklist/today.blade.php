@extends('layout.master')

@section('content')
    <nav class="page-breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('messages.dashboard') }}</a></li>
        <li class="breadcrumb-item active" aria-current="page">{{ __('messages.todays_worklist') }} ({{ \Carbon\Carbon::today()->format('d M, Y') }})</li>
    </ol>
    </nav>

    <div class="row">
        {{-- আজকের টার্গেট এবং সারাংশ --}}
        <div class="col-md-12 grid-margin">
            <div class="card">
                <div class="card-header bg-primary">
                    <h5 class="card-title mb-0 text-white  ">{{ __('messages.todays_summary_and_targets') }}</h5>
                </div>
                <div class="card-body">

                    <div class="row text-center">
                        <div class="col-md-4">
                            <div class="card-title  ">{{ __('messages.outstanding_loan_installments') }}</div>
                            <h4 class="text-danger">{{ $loanInstallmentsDueToday->count() }} {{ __('messages.accounts') }}</h4>
                        </div>
                        <div class="col-md-4">
                            <div class="card-title  ">{{ __('messages.outstanding_savings_collections') }}</div>
                            <h4 class="text-success">{{ $savingsDueToday->count() }} {{ __('messages.accounts') }}</h4>
                        </div>
                        <div class="col-md-4">
                            <div class="card-title  ">{{ __('messages.todays_loan_collection_target') }}</div>
                            <h4 class="text-primary">{{ number_format($totalTarget, 2) }} BDT</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        {{-- ঋণের কিস্তি তালিকা --}}
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-header bg-danger">
                    <h6 class="card-title text-white mb-0 ">{{ __('messages.loan_installments_due') }}</h6>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                            <tr>
                                <th class="  ">{{ __('messages.member') }}</th>
                                <th class="  ">{{ __('messages.account_no') }}</th>
                                <th class="text-end  ">{{ __('messages.amount') }}</th>
                                <th class="  ">{{ __('messages.action') }}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse ($loanInstallmentsDueToday as $loan)
                                <tr id="loan-row-{{ $loan->id }}">
                                    <td class="">
                                        <a href="{{ route('members.show', $loan->member->id) }}">{{ $loan->member->name }}</a>
                                        <br><small>{{ $loan->member->mobile_no }}</small>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger">{{ $loan->member->account_no }}</span>
                                    </td>
                                    <td class="text-end ">{{ number_format($loan->installment_amount, 2) }}</td>
                                    <td>
                                        <button type="button" 
                                            class="btn btn-primary btn-xs fw-bolder collect-btn"
                                            data-member-id="{{ $loan->member_id }}"
                                            data-member-name="{{ $loan->member->name }}"
                                            data-account-no="{{ $loan->account_no }}"
                                            data-amount="{{ $loan->installment_amount }}"
                                            data-loan-id="{{ $loan->id }}">
                                            {{ __('messages.collect') }}
                                        </button>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center text-muted">{{ __('messages.no_outstanding_loan_installments') }}</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        {{-- সঞ্চয় আদায় তালিকা --}}
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-header bg-success">
                    <h6 class="card-title text-white mb-0 ">{{ __('messages.savings_collections_due') }}</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                            <tr>
                                <th class="  ">{{ __('messages.member') }}</th>
                                <th class="  ">{{ __('messages.due_date') }}</th>
                                <th class="text-end  ">{{ __('messages.scheme') }}</th>
                                <th class="  ">{{ __('messages.action') }}</th>
                            </tr>
                            </thead>
                            <tbody>
                            @forelse ($savingsDueToday as $saving)
                                <tr>
                                    <td class="">
                                        <a href="{{ route('members.show', $saving->member->id) }}">{{ $saving->member->name }}</a>
                                        <br><small>{{ $saving->member->mobile_no }}</small>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger">{{ \Carbon\Carbon::parse($saving->next_due_date)->format('d M, Y') }}</span>
                                    </td>
                                    <td class="text-end">{{ __('messages.'.$saving->scheme_type) }}</td>
                                    <td>
                                        <a href="{{ route('savings-accounts.show',$saving->id) }}" class="btn btn-primary btn-xs fw-bolder">{{ __('messages.collect') }}</a>
                                    </td>
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="4" class="text-center text-muted">{{ __('messages.no_outstanding_savings_collections') }}</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    @include('worklist.partials._collection_modal')
@endsection

@push('plugin-styles')
    <link rel="stylesheet" href="{{ asset('build/plugins/flatpickr/flatpickr.min.css') }}">
    <style>
        .form-control-premium {
            border-radius: 0.75rem;
            padding: 0.65rem 1rem;
            border: 1px solid #e2e8f0;
            background-color: #f8fafc;
            transition: all 0.2s ease;
        }

        .form-control-premium:focus {
            background-color: #fff;
            border-color: #f43f5e;
            box-shadow: 0 0 0 4px rgba(244, 63, 94, 0.1);
        }

        .btn-submit {
            background: linear-gradient(135deg, #f43f5e 0%, #e11d48 100%);
            border: none;
            border-radius: 0.75rem;
            padding: 0.75rem 2rem;
            font-weight: 600;
            color: white;
            transition: all 0.3s;
        }
        .btn-submit:hover {
            transform: translateY(-2px);
            box-shadow: 0 10px 15px -3px rgba(225, 29, 72, 0.3);
            color: white;
        }
    </style>
@endpush

@push('plugin-scripts')
    {{-- Scripts already in master.blade.php --}}
@endpush

@push('custom-scripts')
    <script>
        $(function() {
            $(".flatpickr").flatpickr({
                altInput: true,
                dateFormat: 'Y-m-d',
                altFormat: 'd/m/Y'
            });

            const collectionModal = new bootstrap.Modal(document.getElementById('loanCollectionModal'));
            const $form = $('#loanCollectionForm');

            $('.collect-btn').on('click', function(e) {
                e.preventDefault();
                const $btn = $(this);
                const memberId = $btn.data('member-id');
                const memberName = $btn.data('member-name');
                const accountNo = $btn.data('account-no');
                const amount = $btn.data('amount');
                const loanId = $btn.data('loan-id');

                $('#form_member_id').val(memberId);
                $('#form_loan_account_id').val(loanId);
                $('#modal_member_name').text(memberName);
                $('#modal_account_no').text(accountNo);
                $form.find('.paid_amount_input').val(amount);

                // Reset submit button state
                const $submitBtn = $form.find('button[type="submit"]');
                $submitBtn.prop('disabled', false).html("{{ __('messages.submit_installment') }}");

                // Ensure date is reset to today
                const fp = $form.find('.flatpickr')[0]?._flatpickr;
                if (fp) {
                    fp.setDate(new Date());
                } else {
                    $form.find('input[name="date"]').val("{{ date('Y-m-d') }}");
                    $form.find('input[name="date_display"]').val("{{ date('d/m/Y') }}");
                }
                
                // Set loan account context if needed, though collections.store handles it
                $form.attr('data-row-id', 'loan-row-' + loanId);

                collectionModal.show();
            });

            $form.on('submit', function(e) {
                e.preventDefault();
                const $submitBtn = $form.find('button[type="submit"]');
                const originalBtnText = $submitBtn.html();
                
                $submitBtn.prop('disabled', true).html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Processing...');

                $.ajax({
                    url: $form.attr('action'),
                    method: 'POST',
                    data: $form.serialize(),
                    success: function(response) {
                        collectionModal.hide();
                        Swal.fire({
                            icon: 'success',
                            title: 'Success!',
                            text: response.message,
                            timer: 2000,
                            showConfirmButton: false
                        });

                        const rowId = $form.attr('data-row-id');
                        $('#' + rowId).fadeOut(400, function() {
                            $(this).remove();
                            // Update counts if necessary
                        });
                        
                        $form[0].reset();
                    },
                    error: function(xhr) {
                        let errorMsg = 'Something went wrong.';
                        if (xhr.responseJSON && xhr.responseJSON.message) {
                            errorMsg = xhr.responseJSON.message;
                        }
                        
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: errorMsg
                        });
                    },
                    complete: function() {
                        $submitBtn.prop('disabled', false).html(originalBtnText);
                    }
                });
            });
        });
    </script>
@endpush
