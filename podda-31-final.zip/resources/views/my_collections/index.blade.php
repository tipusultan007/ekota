@extends('layout.master')

@push('plugin-styles')
    <style>
        .card { border: none; border-radius: 12px; overflow: hidden; }
        .card-header { border-bottom: none; padding: 1.25rem; }
        .nav-tabs-line .nav-link { border-bottom: 3px solid transparent; font-weight: 600; color: #6c757d; padding: 12px 20px; }
        .nav-tabs-line .nav-link.active { border-bottom-color: #6571ff; color: #6571ff; background: transparent; }
        .table-responsive { padding: 0 15px 15px; }
        .table thead th { background-color: #f8f9fc; text-transform: uppercase; font-size: 0.75rem; letter-spacing: 0.05em; font-weight: 700; border-top: none; }
        .filter-section { background: #fff; padding: 15px; border-radius: 12px; margin-bottom: 20px; display: flex; align-items: center; gap: 10px; flex-wrap: wrap; }
        .pagination { margin-top: 15px; justify-content: flex-end; }
        .total-row { background-color: #f1f5f9; font-weight: bold; }
        
        /* Compact Table Styles */
        .table-compact {
            font-size: 0.8rem;
            width: 100%;
        }
        .table-compact th, .table-compact td {
            padding: 6px 4px !important;
            vertical-align: middle;
        }
        .col-date { width: 75px; }
        .col-acc { width: 60px; text-align: center; }
        .col-amount { width: 70px; }
        .member-cell { 
            max-width: 110px; 
            overflow: hidden; 
            text-overflow: ellipsis; 
            white-space: nowrap; 
        }

        @media (max-width: 767.98px) {
            .filter-section { flex-direction: column; align-items: stretch; padding: 10px; }
            .nav-tabs-line .nav-link { padding: 8px 10px; font-size: 0.75rem; }
            .table-compact { font-size: 0.72rem; }
            .table-responsive { padding: 0 5px 5px; }
            .col-date { width: 65px; }
            .col-acc { width: 50px; }
            .member-cell { max-width: 85px; }
        }
    </style>
@endpush

@section('content')
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{ __('messages.dashboard') }}</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ __('messages.my_collection_history') }}</li>
        </ol>
    </nav>

    {{-- Date Filter Section --}}
    <div class="filter-section shadow-sm">
        <form action="{{ route('my_collections.index') }}" method="GET" class="d-flex align-items-center gap-2 w-100">
            <div class="flex-grow-1">
                <label class="small text-muted mb-1 d-block">{{ __('messages.filter_by_date') ?? 'Filter by Date' }}</label>
                <div class="input-group">
                    <span class="input-group-text bg-white border-end-0"><i data-lucide="calendar" style="width: 16px;"></i></span>
                    <input type="date" name="date" class="form-control border-start-0" value="{{ $date }}" onchange="this.form.submit()">
                </div>
            </div>
            <div class="align-self-end">
                <a href="{{ route('my_collections.index') }}" class="btn btn-light border">
                    <i data-lucide="refresh-cw" style="width: 16px;"></i>
                </a>
            </div>
        </form>
    </div>

    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card shadow-sm">
                <div class="card-header bg-white">
                    <h6 class="card-title mb-0 text-primary d-flex align-items-center">
                        <i class="link-icon me-2" data-lucide="history"></i>
                        {{ __('messages.collection_history') }}
                        <span class="ms-2 badge bg-soft-primary small" style="font-size: 0.75rem;">{{ \Carbon\Carbon::parse($date)->format('d M, Y') }}</span>
                    </h6>
                </div>
                <div class="card-body p-0">
                    <ul class="nav nav-tabs nav-tabs-line px-3" id="myCollectionTab" role="tablist">
                        <li class="nav-item">
                            <a class="nav-link {{ !request()->has('loans_page') ? 'active' : '' }}" id="savings-tab" data-bs-toggle="tab" href="#savings" role="tab" aria-controls="savings" aria-selected="true">
                                <i class="link-icon me-1" data-lucide="piggy-bank" style="width: 16px; height: 16px;"></i>
                                {{ __('messages.savings_collections') }}
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link {{ request()->has('loans_page') ? 'active' : '' }}" id="loans-tab" data-bs-toggle="tab" href="#loans" role="tab" aria-controls="loans" aria-selected="false">
                                <i class="link-icon me-1" data-lucide="banknote" style="width: 16px; height: 16px;"></i>
                                {{ __('messages.loan_installments') }}
                            </a>
                        </li>
                    </ul>

                    <div class="tab-content" id="myCollectionTabContent">
                        {{-- Savings Collections Tab --}}
                        <div class="tab-pane fade show {{ !request()->has('loans_page') ? 'active' : '' }}" id="savings" role="tabpanel" aria-labelledby="savings-tab">
                            <div class="table-responsive pt-3">
                                <table class="table table-hover table-compact w-100">
                                    <thead>
                                        <tr>
                                            <th class="col-date">{{ __('messages.date') }}</th>
                                            <th>{{ __('messages.member_name') ?? 'Member' }}</th>
                                            <th class="col-acc">{{ __('messages.account_no') }}</th>
                                            <th class="text-end col-amount">{{ __('messages.deposit') }}</th>
                                            <th class="text-end col-amount">{{ __('messages.withdraw') }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php $totalDeposit = 0; $totalWithdraw = 0; @endphp
                                        @forelse($savings as $item)
                                            @php $totalDeposit += $item->amount; $totalWithdraw += $item->withdraw_amount; @endphp
                                            <tr>
                                                <td class="col-date">{{ $item->collection_date->format('d/m/y') }}</td>
                                                <td class="member-cell" title="{{ $item->member->name }}">{{ $item->member->name }}</td>
                                                <td class="col-acc">{{ $item->savingsAccount->account_no }}</td>
                                                <td class="text-end text-success fw-bold col-amount">{{ number_format($item->amount, 0) }}</td>
                                                <td class="text-end text-danger fw-bold col-amount">{{ number_format($item->withdraw_amount, 0) }}</td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="5" class="text-center py-4 text-muted">{{ __('messages.no_data_found') ?? 'No collections found for this date.' }}</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                    @if($savings->count() > 0)
                                        <tfoot>
                                            <tr class="total-row">
                                                <td colspan="3" class="text-end">{{ __('messages.total') }}</td>
                                                <td class="text-end text-success">{{ number_format($totalDeposit, 0) }}</td>
                                                <td class="text-end text-danger">{{ number_format($totalWithdraw, 0) }}</td>
                                            </tr>
                                        </tfoot>
                                    @endif
                                </table>
                                <div class="d-flex justify-content-end px-3">
                                    {{ $savings->appends(['date' => $date, 'loans_page' => request('loans_page')])->links() }}
                                </div>
                            </div>
                        </div>

                        {{-- Loan Installments Tab --}}
                        <div class="tab-pane fade show {{ request()->has('loans_page') ? 'active' : '' }}" id="loans" role="tabpanel" aria-labelledby="loans-tab">
                            <div class="table-responsive pt-3">
                                <table class="table table-hover table-compact w-100">
                                    <thead>
                                        <tr>
                                            <th class="col-date">{{ __('messages.date') }}</th>
                                            <th>{{ __('messages.member_name') ?? 'Member' }}</th>
                                            <th class="col-acc">{{ __('messages.account_no') }}</th>
                                            <th class="text-end col-amount">{{ __('messages.installment_amount') ?? 'Amount' }}</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        @php $totalLoan = 0; @endphp
                                        @forelse($loans as $item)
                                            @php $totalLoan += $item->paid_amount; @endphp
                                            <tr>
                                                <td class="col-date">{{ $item->payment_date->format('d/m/y') }}</td>
                                                <td class="member-cell" title="{{ $item->member->name }}">{{ $item->member->name }}</td>
                                                <td class="col-acc">{{ $item->loanAccount->account_no }}</td>
                                                <td class="text-end text-primary fw-bold col-amount">{{ number_format($item->paid_amount, 0) }}</td>
                                            </tr>
                                        @empty
                                            <tr>
                                                <td colspan="4" class="text-center py-4 text-muted">{{ __('messages.no_data_found') ?? 'No installments found for this date.' }}</td>
                                            </tr>
                                        @endforelse
                                    </tbody>
                                    @if($loans->count() > 0)
                                        <tfoot>
                                            <tr class="total-row">
                                                <td colspan="3" class="text-end">{{ __('messages.total') }}</td>
                                                <td class="text-end text-primary">{{ number_format($totalLoan, 0) }}</td>
                                            </tr>
                                        </tfoot>
                                    @endif
                                </table>
                                <div class="d-flex justify-content-end px-3">
                                    {{ $loans->appends(['date' => $date, 'savings_page' => request('savings_page')])->links() }}
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection

@push('custom-scripts')
    <script>
        $(document).ready(function() {
            if (typeof lucide !== 'undefined') {
                lucide.createIcons();
            }
        });
    </script>
@endpush
