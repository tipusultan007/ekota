<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Models\SavingsCollection;
use App\Models\LoanInstallment;
use Carbon\Carbon;

class MyCollectionController extends Controller
{
    /**
     * Display the collections page with server-side pagination and date filter.
     */
    public function index(Request $request)
    {
        $date = $request->get('date', Carbon::today()->toDateString());
        $perPage = 20;

        // Savings Collections
        $savings = SavingsCollection::with('member', 'savingsAccount')
            ->where('collector_id', Auth::id())
            ->whereDate('collection_date', $date)
            ->latest('collection_date')
            ->paginate($perPage, ['*'], 'savings_page');

        // Loan Installments
        $loans = LoanInstallment::with('member', 'loanAccount')
            ->where('collector_id', Auth::id())
            ->whereDate('payment_date', $date)
            ->latest('payment_date')
            ->paginate($perPage, ['*'], 'loans_page');

        return view('my_collections.index', compact('savings', 'loans', 'date'));
    }
}
