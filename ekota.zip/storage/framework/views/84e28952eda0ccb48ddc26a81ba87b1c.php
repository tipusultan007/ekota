<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.chart_of_accounts')); ?></li>
        </ol>
    </nav>

    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h5 class="card-title"><?php echo e(__('messages.all_accounts')); ?></h5>
                <a href="<?php echo e(route('admin.accounts.create')); ?>" class="btn btn-primary btn-sm"><?php echo e(__('messages.add_new_account')); ?></a>
            </div>
            <?php if(session('success')): ?> <div class="alert alert-success"><?php echo e(session('success')); ?></div> <?php endif; ?>
            <?php if(session('error')): ?> <div class="alert alert-danger"><?php echo e(session('error')); ?></div> <?php endif; ?>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th><?php echo e(__('messages.account_name')); ?></th><th><?php echo e(__('messages.details_acc_no')); ?></th><th class="text-end"><?php echo e(__('messages.balance')); ?></th><th><?php echo e(__('messages.status')); ?></th><th><?php echo e(__('messages.actions')); ?></th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('admin.accounts.show', $account->id)); ?>"><?php echo e($account->name); ?></a></td>
                            <td><?php echo e($account->details); ?></td>
                            <?php
                                // কন্ট্রোলার থেকে আসা pre-calculated মান ব্যবহার করুন
                                $balance = $account->total_credits - $account->total_debits;
                            ?>
                            <td class="text-end fw-bold"><?php echo e(number_format($balance, 2)); ?></td>
                            <td><span class="badge bg-<?php echo e($account->is_active ? 'success' : 'danger'); ?>"><?php echo e($account->is_active ? __('messages.active') : __('messages.inactive')); ?></span></td>
                            <td>
                                <div class="d-flex">
                                    <a href="<?php echo e(route('admin.accounts.edit', $account->id)); ?>" class="btn btn-primary btn-xs me-1"><?php echo e(__('messages.edit')); ?></a>
                                    <form id="delete-account-<?php echo e($account->id); ?>" action="<?php echo e(route('admin.accounts.destroy', $account->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button type="button" class="btn btn-danger btn-xs" onclick="showDeleteConfirm('delete-account-<?php echo e($account->id); ?>', '<?php echo e(__('messages.are_you_sure')); ?>', '<?php echo e(__('messages.confirm_delete_account')); ?>')"><?php echo e(__('messages.delete')); ?></button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="5" class="text-center"><?php echo e(__('messages.no_accounts_found')); ?></td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4"><?php echo e($accounts->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/admin/accounts/index.blade.php ENDPATH**/ ?>