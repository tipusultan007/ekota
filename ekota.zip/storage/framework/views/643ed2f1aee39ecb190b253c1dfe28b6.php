<nav class="sidebar">
    <div class="sidebar-header">
        <a href="<?php echo e(route('dashboard')); ?>" class="sidebar-brand">
            সমিতি<span>সফট</span>
        </a>
        <div class="sidebar-toggler not-active">
            <span></span>
            <span></span>
            <span></span>
        </div>
    </div>
    <div class="sidebar-body">
        <ul class="nav" id="sidebarNav">

            
            <li class="nav-item nav-category"><?php echo e(__('messages.main')); ?></li>
            <li class="nav-item <?php echo e(active_class(['dashboard'])); ?>">
                <a href="<?php echo e(route('dashboard')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="home"></i>
                    <span class="link-title"><?php echo e(__('messages.dashboard')); ?></span>
                </a>
            </li>

            <li class="nav-item <?php echo e(active_class(['daily-worklist'])); ?>">
                <a href="<?php echo e(route('worklist.today')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="clipboard-list"></i>
                    <span class="link-title"><?php echo e(__('messages.todays_worklist')); ?></span>
                </a>
            </li>


            
            <li class="nav-item nav-category"><?php echo e(__('messages.operations')); ?></li>
            <li class="nav-item <?php echo e(active_class(['collections/create'])); ?>">
                <a href="<?php echo e(route('collections.create')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="dollar-sign"></i>
                    <span class="link-title"><?php echo e(__('messages.collections')); ?></span>
                </a>
            </li>

            <li class="nav-item <?php echo e(active_class(['loan-installments/create'])); ?>">
                <a href="<?php echo e(route('loan-installments.create')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="trending-up"></i>
                    <span class="link-title"><?php echo e(__('messages.loan_collection')); ?></span>
                </a>
            </li>


            
            <li class="nav-item nav-category"><?php echo e(__('messages.accounts')); ?></li>
            <li class="nav-item <?php echo e(active_class(['members*'])); ?>">
                <a href="<?php echo e(route('members.index')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="users"></i>
                    <span class="link-title"><?php echo e(__('messages.member_management')); ?></span>
                </a>
            </li>
            <li class="nav-item <?php echo e(active_class(['savings-accounts*'])); ?>">
                <a href="<?php echo e(route('savings_accounts.index')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="wallet"></i>
                    <span class="link-title"><?php echo e(__('messages.savings_accounts')); ?></span>
                </a>
            </li>
            <li class="nav-item <?php echo e(active_class(['loan-accounts*'])); ?>">
                <a href="<?php echo e(route('loan_accounts.index')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="hand-coins"></i>
                    <span class="link-title"><?php echo e(__('messages.loan_accounts')); ?></span>
                </a>
            </li>

            <li class="nav-item <?php echo e(active_class(['savings-collections', 'loan-installments', 'savings-withdrawals*'])); ?>">
                <a class="nav-link" data-bs-toggle="collapse" href="#history" role="button"
                   aria-expanded="<?php echo e(is_active_route(['savings-collections', 'loan-installments', 'savings-withdrawals*'])); ?>"
                   aria-controls="history">
                    <i class="link-icon" data-lucide="archive"></i>
                    <span class="link-title"><?php echo e(__('messages.collection_report')); ?></span>
                    <i class="link-arrow" data-lucide="chevron-down"></i>
                </a>
                <div
                    class="collapse <?php echo e(show_class(['savings-collections', 'loan-installments', 'savings-withdrawals*'])); ?>"
                    id="history">
                    <ul class="nav sub-menu">
                        <li class="nav-item">
                            <a href="<?php echo e(route('savings-collections.index')); ?>"
                               class="nav-link <?php echo e(active_class(['savings-collections'])); ?>"><?php echo e(__('messages.collection_history')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('loan-installments.index')); ?>"
                               class="nav-link <?php echo e(active_class(['loan-installments'])); ?>"><?php echo e(__('messages.installment_history')); ?></a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('savings_withdrawals.index')); ?>"
                               class="nav-link <?php echo e(active_class(['savings-withdrawals*'])); ?>"><?php echo e(__('messages.withdrawal_history')); ?></a>
                        </li>
                    </ul>
                </div>
            </li>


            
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
            <li class="nav-item nav-category"><?php echo e(__('messages.reports')); ?></li>
            <li class="nav-item <?php echo e(active_class(['reports/*'])); ?>">
                <a class="nav-link" data-bs-toggle="collapse" href="#reports" role="button"
                   aria-expanded="<?php echo e(is_active_route(['reports/*'])); ?>" aria-controls="reports">
                    <i class="link-icon" data-lucide="bar-chart-2"></i>
                    <span class="link-title"><?php echo e(__('messages.reports')); ?></span>
                    <i class="link-arrow" data-lucide="chevron-down"></i>
                </a>
                <div class="collapse <?php echo e(show_class(['reports/*'])); ?>" id="reports">
                    <ul class="nav sub-menu">
                        <li class="nav-item"><a href="<?php echo e(route('reports.daily_collection.form')); ?>"
                                                class="nav-link <?php echo e(active_class(['reports/daily-collection'])); ?>"><?php echo e(__('messages.daily_collection_report')); ?></a>
                        </li>
                        <li class="nav-item"><a href="<?php echo e(route('reports.daily_transaction_log')); ?>"
                                                class="nav-link <?php echo e(active_class(['reports/daily-transaction-log'])); ?>"><?php echo e(__('messages.daily_transaction_log')); ?></a>
                        </li>
                        <li class="nav-item"><a href="<?php echo e(route('reports.outstanding_loan')); ?>"
                                                class="nav-link <?php echo e(active_class(['reports/outstanding-loan'])); ?>"><?php echo e(__('messages.outstanding_loans')); ?></a>
                        </li>
                        <li class="nav-item"><a href="<?php echo e(route('admin.reports.financial_summary')); ?>"
                                                class="nav-link <?php echo e(active_class(['admin/reports/financial-summary'])); ?>"><?php echo e(__('messages.financial_summary')); ?></a>
                        </li>
                         <li class="nav-item">
                            <a href="<?php echo e(route('admin.reports.area_wise')); ?>" class="nav-link <?php echo e(active_class(['admin/reports/area-wise'])); ?>"><?php echo e(__('messages.area_wise_report')); ?></a>
                        </li>
                    </ul>
                </div>
            </li>
            <?php endif; ?>


            
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
            <li class="nav-item nav-category"><?php echo e(__('messages.management')); ?></li>
            <li class="nav-item <?php echo e(active_class(['admin/areas*'])); ?>">
                <a href="<?php echo e(route('admin.areas.index')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="map-pin"></i>
                    <span class="link-title"><?php echo e(__('messages.area_management')); ?></span>
                </a>
            </li>
            <li class="nav-item <?php echo e(active_class(['admin/users*'])); ?>">
                <a href="<?php echo e(route('admin.users.index')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="user-cog"></i>
                    <span class="link-title"><?php echo e(__('messages.user_management')); ?></span>
                </a>
            </li>
            <li class="nav-item <?php echo e(active_class(['admin/capital-investments*'])); ?>">
                <a href="<?php echo e(route('admin.capital_investments.index')); ?>" class="nav-link">
                    <i class="link-icon" data-lucide="trending-up"></i>
                    <span class="link-title"><?php echo e(__('messages.capital_investment')); ?></span>
                </a>
            </li>
            <li class="nav-item <?php echo e(active_class(['admin/expense*'])); ?>">
                <a class="nav-link" data-bs-toggle="collapse" href="#expense" role="button"
                   aria-expanded="<?php echo e(is_active_route(['admin/expense*'])); ?>" aria-controls="expense">
                    <i class="link-icon" data-lucide="credit-card"></i>
                    <span class="link-title"><?php echo e(__('messages.expense_management')); ?></span>
                    <i class="link-arrow" data-lucide="chevron-down"></i>
                </a>
                <div class="collapse <?php echo e(show_class(['admin/expense*'])); ?>" id="expense">
                    <ul class="nav sub-menu">
                        <li class="nav-item"><a href="<?php echo e(route('admin.expense-categories.index')); ?>"
                                                class="nav-link <?php echo e(active_class(['admin/expense-categories*'])); ?>"><?php echo e(__('messages.expense_categories')); ?></a>
                        </li>
                        <li class="nav-item"><a href="<?php echo e(route('admin.expenses.index')); ?>"
                                                class="nav-link <?php echo e(active_class(['admin/expenses*'])); ?>"><?php echo e(__('messages.all_expenses')); ?></a>
                        </li>
                    </ul>
                </div>
            </li>
            <li class="nav-item <?php echo e(active_class(['admin/salaries*'])); ?>">
                <a class="nav-link" data-bs-toggle="collapse" href="#salary" ...>
                    <i class="link-icon" data-lucide="wallet"></i>
                    <span class="link-title"><?php echo e(__('messages.salary_management')); ?></span>
                </a>
                <div class="collapse <?php echo e(show_class(['admin/salaries*'])); ?>" id="salary">
                    <ul class="nav sub-menu">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.salaries.create')); ?>" class="nav-link <?php echo e(active_class(['admin/salaries/create'])); ?>">
                                <?php echo e(__('messages.pay_salary')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.salaries.index')); ?>" class="nav-link <?php echo e(active_class(['admin/salaries'])); ?>">
                                <?php echo e(__('messages.payment_history')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <?php endif; ?>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
            <li class="nav-item <?php echo e(active_class(['admin/accounts*', 'admin/account-transfers*'])); ?>">
                <a class="nav-link" data-bs-toggle="collapse" href="#chartOfAccounts">
                    <i class="link-icon" data-lucide="book"></i>
                    <span class="link-title"><?php echo e(__('messages.chart_of_accounts')); ?></span>
                    <i class="link-arrow" data-lucide="chevron-down"></i>
                </a>
                <div class="collapse <?php echo e(show_class(['admin/accounts*', 'admin/account-transfers*'])); ?>" id="chartOfAccounts">
                    <ul class="nav sub-menu">
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.accounts.index')); ?>" class="nav-link <?php echo e(active_class(['admin/accounts*'])); ?>">
                                <?php echo e(__('messages.all_accounts')); ?>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('admin.account-transfers.index')); ?>" class="nav-link <?php echo e(active_class(['admin/account-transfers*'])); ?>">
                                <?php echo e(__('messages.balance_transfer')); ?>

                            </a>
                        </li>
                    </ul>
                </div>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH C:\wamp64\www\ekota\resources\views/layout/partials/sidebar.blade.php ENDPATH**/ ?>