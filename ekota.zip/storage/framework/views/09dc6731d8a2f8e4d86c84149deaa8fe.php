<?php $__env->startPush('plugin-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('build/plugins/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-center">
                <div>
                    <h5 class="card-title"><?php echo e(__('messages.account_details')); ?>: <?php echo e($account->name); ?></h5>
                    <p class="text-muted mb-0"><strong><?php echo e(__('messages.closing_balance')); ?>:</strong> <span class="fw-bold fs-5"><?php echo e(number_format($account->calculatedBalance, 2)); ?></span></p>
                </div>
                <a href="<?php echo e(route('admin.accounts.index')); ?>" class="btn btn-secondary btn-sm"><?php echo e(__('messages.back_to_list')); ?></a>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-6 grid-margin">
            <div class="card bg-success text-white">
                <div class="card-body text-center">
                    <h6 class="text-uppercase small"><?php echo e(__('messages.total_credit')); ?></h6>
                    <h4 class="mb-0"><?php echo e(number_format($totalCredit, 2)); ?></h4>
                    <?php if(request('start_date')): ?> <small>(in selected range)</small> <?php endif; ?>
                </div>
            </div>
        </div>
        <div class="col-md-6 grid-margin">
            <div class="card bg-danger text-white">
                <div class="card-body text-center">
                    <h6 class="text-uppercase small"><?php echo e(__('messages.total_debit')); ?></h6>
                    <h4 class="mb-0"><?php echo e(number_format($totalDebit, 2)); ?></h4>
                    <?php if(request('start_date')): ?> <small>(in selected range)</small> <?php endif; ?>
                </div>
            </div>
        </div>
    </div>

    <div class="card mt-2">
        <div class="card-body">
            <h5 class="card-title"><?php echo e(__('messages.transaction_history_ledger')); ?></h5>

            
            <form action="<?php echo e(route('admin.accounts.show', $account->id)); ?>" method="GET" class="mb-4">
                <div class="row">
                    <div class="col-md-5"><input type="text" name="start_date" class="form-control flatpickr" value="<?php echo e(request('start_date')); ?>" placeholder="<?php echo e(__('messages.start_date')); ?>"></div>
                    <div class="col-md-5"><input type="text" name="end_date" class="form-control flatpickr" value="<?php echo e(request('end_date')); ?>" placeholder="<?php echo e(__('messages.end_date')); ?>"></div>
                    <div class="col-md-2 d-flex align-items-center"><button type="submit" class="btn btn-primary btn-sm me-2"><?php echo e(__('messages.filter')); ?></button><a href="<?php echo e(route('admin.accounts.show', $account->id)); ?>" class="btn btn-secondary btn-sm"><?php echo e(__('messages.reset')); ?></a></div>
                </div>
            </form>

            <div class="table-responsive">
                <table class="table table-hover">
                    <thead><tr><th><?php echo e(__('messages.date')); ?></th><th><?php echo e(__('messages.description')); ?></th><th class="text-end"><?php echo e(__('messages.debit')); ?></th><th class="text-end"><?php echo e(__('messages.credit')); ?></th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transaction): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($transaction->transaction_date->format('d M, Y')); ?></td>
                            <td><?php echo e($transaction->description); ?></td>
                            <?php if($transaction->type == 'debit'): ?>
                                <td class="text-end text-danger"><?php echo e(number_format($transaction->amount, 2)); ?></td>
                                <td class="text-end">-</td>
                            <?php else: ?>
                                <td class="text-end">-</td>
                                <td class="text-end text-success"><?php echo e(number_format($transaction->amount, 2)); ?></td>
                            <?php endif; ?>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="4" class="text-center"><?php echo e(__('messages.no_transactions_found')); ?></td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4"><?php echo e($transactions->appends(request()->query())->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('build/plugins/flatpickr/flatpickr.min.js')); ?>"></script>
    <script>
        $(".flatpickr").flatpickr({
            altInput: true,
            dateFormat: 'Y-m-d',
            altFormat: 'd/m/Y',
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/admin/accounts/show.blade.php ENDPATH**/ ?>