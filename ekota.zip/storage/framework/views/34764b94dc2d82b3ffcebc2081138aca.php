<?php $__env->startSection('content'); ?>

    <div class="row">
        
        <div class="col-lg-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"><?php echo e(__('messages.new_loan_application')); ?></h6>
                    <?php if(session('error')): ?> <div class="alert alert-danger"><?php echo e(session('error')); ?></div> <?php endif; ?>
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <form action="<?php echo e(route('loan.new.store')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="mb-4">
                            <label for="member_id" class="form-label"><?php echo e(__('messages.select_member')); ?> <span class="text-danger">*</span></label>
                            <select name="member_id" id="member_id" class="form-select" required>
                                <option value=""><?php echo e(__('messages.search_select_member')); ?></option>
                                <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($member->id); ?>" <?php echo e(old('member_id') == $member->id ? 'selected' : ''); ?>>
                                        <?php echo e($member->name); ?> (<?php echo e(__('messages.id')); ?>: <?php echo e($member->id); ?>)
                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['member_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback d-block"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        
                        <h5 class="mb-3 border-bottom pb-2"><?php echo e(__('messages.loan_details')); ?></h5>
                        <div class="row">
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.disburse_from_account')); ?> <span class="text-danger">*</span></label>
                                <select name="account_id" class="form-select <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                    <option value=""><?php echo e(__('messages.select_account')); ?></option>
                                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($account->id); ?>" <?php echo e(old('account_id') == $account->id ? 'selected' : ''); ?>>
                                            <?php echo e($account->name); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['account_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.loan_amount')); ?></label>
                                <input type="number" name="loan_amount" id="loan_amount" class="form-control <?php $__errorArgs = ['loan_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('loan_amount')); ?>" required>
                                <?php $__errorArgs = ['loan_amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.interest_rate')); ?> (%)</label>
                                <input type="number" step="0.01" name="interest_rate" id="interest_rate" class="form-control <?php $__errorArgs = ['interest_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('interest_rate')); ?>" required>
                                <?php $__errorArgs = ['interest_rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.number_of_installments')); ?></label>
                                <input type="number" name="number_of_installments" id="number_of_installments" class="form-control <?php $__errorArgs = ['number_of_installments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('number_of_installments')); ?>" required>
                                <?php $__errorArgs = ['number_of_installments'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.installment_amount')); ?></label>
                                <input type="text" id="calculated_installment" class="form-control" readonly style="background-color: #e9ecef;">
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.installment_frequency')); ?> <span class="text-danger">*</span></label>
                                <select name="installment_frequency" class="form-select" required>
                                    <option value="daily"><?php echo e(__('messages.daily')); ?></option>
                                    <option value="weekly"><?php echo e(__('messages.weekly')); ?></option>
                                    <option value="monthly" selected><?php echo e(__('messages.monthly')); ?></option>
                                </select>
                            </div>

                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.disbursement_date')); ?></label>
                                <input type="text" name="disbursement_date" class="form-control flatpickr <?php $__errorArgs = ['disbursement_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('disbursement_date', date('Y-m-d'))); ?>" required>
                                <?php $__errorArgs = ['disbursement_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        
                        <h5 class="mt-4 mb-3 border-bottom pb-2"><?php echo e(__('messages.guarantor_information')); ?></h5>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('messages.guarantor_type')); ?></label>
                            <select name="guarantor_type" id="guarantorType" class="form-select <?php $__errorArgs = ['guarantor_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="" selected disabled>-- <?php echo e(__('messages.select_type')); ?> --</option>
                                <option value="member" <?php echo e(old('guarantor_type') == 'member' ? 'selected' : ''); ?>><?php echo e(__('messages.existing_member')); ?></option>
                                <option value="outsider" <?php echo e(old('guarantor_type') == 'outsider' ? 'selected' : ''); ?>><?php echo e(__('messages.outside_person')); ?></option>
                            </select>
                            <?php $__errorArgs = ['guarantor_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div id="memberGuarantor" style="display: <?php echo e(old('guarantor_type') == 'member' ? 'block' : 'none'); ?>;">
                            <div class="mb-3">
                                <label class="form-label"><?php echo e(__('messages.select_member_as_guarantor')); ?></label>
                                <select name="member_guarantor_id" class="form-select <?php $__errorArgs = ['member_guarantor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <option value="">-- <?php echo e(__('messages.select_member')); ?> --</option>
                                    <?php $__currentLoopData = $guarantors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guarantor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($guarantor->id); ?>" <?php echo e(old('member_guarantor_id') == $guarantor->id ? 'selected' : ''); ?>>
                                            <?php echo e($guarantor->name); ?> (<?php echo e(__('messages.id')); ?>: <?php echo e($guarantor->id); ?>)
                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['member_guarantor_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>

                        <div id="outsiderGuarantor" style="display: <?php echo e(old('guarantor_type') == 'outsider' ? 'block' : 'none'); ?>;">
                            <div class="row">
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.name')); ?></label>
                                    <input type="text" name="outsider_name" class="form-control <?php $__errorArgs = ['outsider_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('outsider_name')); ?>">
                                    <?php $__errorArgs = ['outsider_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.phone')); ?></label>
                                    <input type="text" name="outsider_phone" class="form-control <?php $__errorArgs = ['outsider_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(old('outsider_phone')); ?>">
                                    <?php $__errorArgs = ['outsider_phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.address')); ?></label>
                                    <textarea name="outsider_address" class="form-control <?php $__errorArgs = ['outsider_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('outsider_address')); ?></textarea>
                                    <?php $__errorArgs = ['outsider_address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.nid_photo')); ?></label>
                                    <input type="file" name="guarantor_nid" class="form-control <?php $__errorArgs = ['guarantor_nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['guarantor_nid'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <div class="invalid-feedback"><?php echo e($message); ?></div> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                                <div class="col-md-6 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.other_documents')); ?></label>
                                    <input type="file" name="guarantor_documents[]" class="form-control" multiple>
                                </div>
                            </div>
                        </div>

                        
                        <h5 class="mt-4 mb-3 border-bottom pb-2"><?php echo e(__('messages.loan_documents')); ?></h5>
                        <div id="loan-documents-wrapper">
                            <div class="row mb-2 align-items-center">
                                <div class="col-md-5"><input type="text" name="document_names[]" class="form-control" placeholder="<?php echo e(__('messages.document_name_placeholder')); ?>"></div>
                                <div class="col-md-5"><input type="file" name="loan_documents[]" class="form-control"></div>
                                <div class="col-md-2"><button type="button" class="btn btn-sm btn-success" id="add-document-btn"><?php echo e(__('messages.add_more')); ?></button></div>
                            </div>
                        </div>

                        <button type="submit" class="btn btn-primary mt-4"><?php echo e(__('messages.create_loan_account')); ?></button>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e(__('messages.member_summary')); ?></h5>
                    <div id="member_summary_content" class="text-center text-muted mt-4">
                        <p><?php echo e(__('messages.select_member_to_view_summary')); ?></p>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(".form-select").select2({
            width: '100%',
        })
        $(".flatpickr").flatpickr({
            altInput: true,
            dateFormat: 'Y-m-d',
            altFormat: 'd/m/Y'
        })


        document.getElementById('add-document-btn').addEventListener('click', function() {
            const wrapper = document.getElementById('loan-documents-wrapper');
            const newRow = document.createElement('div');
            newRow.className = 'row mb-2 align-items-center';
            newRow.innerHTML = `
        <div class="col-md-5"><input type="text" name="document_names[]" class="form-control" placeholder="Document Name"></div>
        <div class="col-md-5"><input type="file" name="loan_documents[]" class="form-control"></div>
        <div class="col-md-2"><button type="button" class="btn btn-sm btn-danger remove-document-btn">Remove</button></div>
    `;
            wrapper.appendChild(newRow);
        });

        document.addEventListener('click', function(e) {
            if (e.target && e.target.classList.contains('remove-document-btn')) {
                e.target.closest('.row').remove();
            }
        });
    </script>

    <script>
        $(document).ready(function() {
            const memberSelect = $('#member_id');
            const summaryContent = $('#member_summary_content');

            // Initialize Select2
            memberSelect.select2({
                placeholder: "Search and select a member...",
                width: '100%'
            });

            // Member selection change event
            memberSelect.on('change', function() {
                const memberId = $(this).val();

                if (!memberId) {
                    summaryContent.html('<p class="text-muted">Select a member to view their financial summary.</p>');
                    return;
                }

                // Show loading state
                summaryContent.html('<div class="spinner-border spinner-border-sm" role="status"></div>');

                // Fetch member account data via API
                $.ajax({
                    url: `/api/members/${memberId}/accounts`,
                    type: 'GET',
                    success: function(response) {
                        const member = response.member;

                        // Build and display summary HTML
                        let html = `
                        <div class="text-center mb-3">
                            <img src="${member.photo_url}" class="rounded-circle" width="80" height="80" alt="Photo" style="object-fit: cover;">
                        </div>
                        <h6 class="text-center">${member.name}</h6>
                        <p class="text-muted text-center small mb-3">
                            <i data-lucide="phone" class="icon-sm me-1"></i> ${member.phone}
                        </p>
                        <hr>
                    `;

                        // Savings Summary
                        html += '<h6 class="mb-3">Savings Summary</h6>';
                        if (response.savings.length > 0) {
                            let totalSavings = 0;
                            response.savings.forEach(acc => totalSavings += parseFloat(acc.current_balance));
                            html += `<p><strong>Total Balance:</strong> <span class="text-success">${totalSavings.toFixed(2)}</span> in ${response.savings.length} account(s).</p>`;
                        } else {
                            html += '<p class="small text-muted">No active savings accounts.</p>';
                        }

                        // Loan Summary
                        html += '<hr><h6 class="mb-3">Loan Summary</h6>';
                        if (response.loans.length > 0) {
                            let totalDue = 0;
                            response.loans.forEach(acc => totalDue += (parseFloat(acc.total_payable) - parseFloat(acc.total_paid)));
                            html += `<p><strong>Total Due:</strong> <span class="text-danger">${totalDue.toFixed(2)}</span> in ${response.loans.length} account(s).</p>`;
                        } else {
                            html += '<p class="small text-muted">No running loan accounts.</p>';
                        }

                        summaryContent.html(html);
                        lucide.createIcons(); // Render new icons
                    },
                    error: function() {
                        summaryContent.html('<p class="text-danger">Failed to load member summary.</p>');
                    }
                });
            });

            // Trigger change on page load if a member is already selected (due to validation error)
            if (memberSelect.val()) {
                memberSelect.trigger('change');
            }

            const guarantorTypeSelect = $('#guarantorType');
            const memberDiv = $('#memberGuarantor');
            const outsiderDiv = $('#outsiderGuarantor');

            guarantorTypeSelect.on('change', function() {
                if (this.value === 'member') {
                    memberDiv.slideDown();
                    outsiderDiv.slideUp();
                } else if (this.value === 'outsider') {
                    memberDiv.slideUp();
                    outsiderDiv.slideDown();
                } else {
                    memberDiv.slideUp();
                    outsiderDiv.slideUp();
                }
            });

            // Trigger on page load to set initial state (for validation errors)
            guarantorTypeSelect.trigger('change');

            const loanAmountInput = $('#loan_amount');
            const interestRateInput = $('#interest_rate');
            const installmentsInput = $('#number_of_installments');
            const calculatedInstallmentDisplay = $('#calculated_installment');

            function calculateInstallment() {
                const loanAmount = parseFloat(loanAmountInput.val()) || 0;
                const interestRate = parseFloat(interestRateInput.val()) || 0;
                const installments = parseInt(installmentsInput.val()) || 0;

                if (loanAmount > 0 && interestRate >= 0 && installments > 0) {
                    const interest = (loanAmount * interestRate) / 100;
                    const totalPayable = loanAmount + interest;
                    const installmentAmount = totalPayable / installments;

                    // গণনাকৃত মানটি read-only ফিল্ডে দেখান
                    calculatedInstallmentDisplay.val(installmentAmount.toFixed(2));
                } else {
                    calculatedInstallmentDisplay.val(''); // যদি কোনো মান না থাকে তাহলে খালি রাখুন
                }
            }

            // তিনটি ইনপুট ফিল্ডের যেকোনো একটি পরিবর্তন হলেই গণনা আবার চালান
            loanAmountInput.on('input', calculateInstallment);
            interestRateInput.on('input', calculateInstallment);
            installmentsInput.on('input', calculateInstallment);


        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/loan_accounts/new.blade.php ENDPATH**/ ?>