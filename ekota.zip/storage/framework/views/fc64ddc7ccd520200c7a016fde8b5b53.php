<?php $__env->startSection('content'); ?>
    <div class="card mb-4">
        <div class="card-body">
            <h5 class="card-title"><?php echo e(__('add_capital_investment')); ?></h5>
            <form action="<?php echo e(route('admin.capital_investments.store')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('investor')); ?></label>
                        <select name="user_id" class="form-select" required>
                            <option value=""><?php echo e(__('select_investor')); ?></option>
                            <?php $__currentLoopData = $investors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($investor->id); ?>"><?php echo e($investor->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('deposit_to_account')); ?></label>
                        <select name="account_id" class="form-select" required>
                            <option value=""><?php echo e(__('select_account')); ?></option>
                            <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('amount')); ?></label>
                        <input type="number" step="0.01" name="amount" class="form-control" required>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label class="form-label"><?php echo e(__('investment_date')); ?></label>
                        <input type="date" name="investment_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>"
                            required>
                    </div>
                    <div class="col-md-12 mb-3">
                        <label class="form-label"><?php echo e(__('description_notes')); ?></label>
                        <input type="text" name="description" class="form-control">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary"><?php echo e(__('add_investment')); ?></button>
            </form>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <h5 class="card-title"><?php echo e(__('Investment_History')); ?></h5>
            <div class="table-responsive">
                <table class="table table-hover">
                    <thead>
                        <tr>
                            <th><?php echo e(__('date')); ?></th>
                            <th><?php echo e(__('investor')); ?></th>
                            <th class="text-end"><?php echo e(__('amount')); ?></th>
                            <th><?php echo e(__('deposited_to')); ?></th>
                            <th><?php echo e(__('description')); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $investments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $investment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td><?php echo e($investment->investment_date->format('d M, Y')); ?></td>
                                <td><?php echo e($investment->user->name); ?></td>
                                <td class="text-end"><?php echo e(number_format($investment->amount, 2)); ?></td>
                                <td><?php echo e($investment->account->name); ?></td>
                                <td><?php echo e($investment->description); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <tr>
                                <td colspan="5" class="text-center"><?php echo e(__('no_investment_records_found')); ?></td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4"><?php echo e($investments->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/admin/capital_investments/index.blade.php ENDPATH**/ ?>