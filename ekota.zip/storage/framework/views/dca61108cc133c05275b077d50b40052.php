<?php $__env->startPush('plugin-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('build/plugins/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('build/plugins/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.loan_installment_collection')); ?></li>
        </ol>
    </nav>
    <?php if(session('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger" role="alert">
            <?php echo e(session('error')); ?>

        </div>
    <?php endif; ?>

    <div class="row">
        
        <div class="col-lg-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e(__('messages.make_new_loan_collection')); ?></h5>
                    <form action="<?php echo e(route('loan-installments.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-md-8 mb-3">
                                <label class="form-label"><?php echo e(__('messages.select_member_and_loan_account')); ?> <span class="text-danger">*</span></label>
                                <select name="loan_account_id" id="loan_account_id" class="form-select" required>
                                    <option value="">-- <?php echo e(__('messages.select')); ?> --</option>
                                    <?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <optgroup label="<?php echo e($member->name); ?> (ID: <?php echo e($member->id); ?>)">
                                            <?php $__currentLoopData = $member->loanAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($account->id); ?>" data-due="<?php echo e($account->total_payable - $account->total_paid); ?>"><?php echo e($account->account_no); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </optgroup>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="col-md-4 mb-3">
                                <label class="form-label"><?php echo e(__('messages.payment_date')); ?></label>
                                <input type="text" name="payment_date" class="form-control flatpickr" value="<?php echo e(date('Y-m-d')); ?>" required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-5 mb-3">
                                <label class="form-label"><?php echo e(__('messages.amount')); ?> <span class="text-danger">*</span></label>
                                <input type="number" step="0.01" name="paid_amount" id="paid_amount_input" class="form-control" required>
                            </div>
                            <div class="col-md-4 mb-3" id="grace_amount_wrapper">
                                <label class="form-label">Grace Amount</label>
                                <input type="number" step="0.01" name="grace_amount" id="grace_amount_input" class="form-control" placeholder="0.00">
                            </div>
                            <div class="col-md-3 mb-3">
                                <label class="form-label">Deposit To <span class="text-danger">*</span></label>
                                <select name="account_id" class="form-select" required>
                                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label class="form-label"><?php echo e(__('messages.notes')); ?></label>
                            <textarea name="notes" class="form-control" rows="2"></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary"><?php echo e(__('messages.submit_installment')); ?></button>
                    </form>
                </div>
            </div>
        </div>

        
        <div class="col-lg-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Summary</h5>
                    <div id="summary_content" class="text-center text-muted mt-4">
                        <p>Select a loan account to view details.</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="card-title"><?php echo e(__('messages.recent_loan_collections')); ?></h6>
                        <a href="<?php echo e(route('loan-installments.index')); ?>" class="btn btn-secondary btn-sm">
                            <?php echo e(__('messages.view_all_loan_collections')); ?>

                        </a>
                    </div>

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th><?php echo e(__('messages.receipt_no')); ?></th>
                                <th><?php echo e(__('messages.member_name')); ?></th>
                                <th><?php echo e(__('messages.account_no')); ?></th>
                                <th class="text-end"><?php echo e(__('messages.amount')); ?></th>
                                <th class="text-end"><?php echo e(__('messages.grace')); ?></th>
                                <th><?php echo e(__('messages.date')); ?></th>
                                <th><?php echo e(__('messages.collected_by')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $recentInstallments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($installment->id); ?></td>
                                    <td><?php echo e($installment->member->name); ?></td>
                                    <td><?php echo e($installment->loanAccount->account_no); ?></td>
                                    <td class="text-end"><?php echo e(number_format($installment->paid_amount, 2)); ?></td>
                                    <td class="text-end"><?php echo e(number_format($installment->grace_amount, 2)); ?></td>
                                    <td><?php echo e($installment->payment_date->format('d M, Y')); ?></td>
                                    <td><?php echo e($installment->collector->name); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center"><?php echo e(__('messages.no_recent_installments_found')); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('plugin-scripts'); ?>
    
    <script src="<?php echo e(asset('build/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('build/plugins/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('build/plugins/flatpickr/flatpickr.min.js')); ?>"></script>

    <script>
        $(document).ready(function() {
            if ($("#loan_account_id").length) {
                $("#loan_account_id").select2({
                    placeholder: "<?php echo e(__('messages.search_and_select_account')); ?>",
                    width: '100%',
                });
            }

            $(".flatpickr").flatpickr({
                altInput: true,
                dateFormat: "Y-m-d",
                altFormat: "d/m/Y"
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            const loanAccountSelect = $("#loan_account_id");
            const summaryContent = $("#summary_content");
            const paidAmountInput = $('#paid_amount_input');
            const graceAmountWrapper = $('#grace_amount_wrapper');
            let currentDue = 0;

            loanAccountSelect.select2({
                placeholder: "<?php echo e(__('messages.search_and_select_account')); ?>",
                width: '100%',
            });

            $(".flatpickr").flatpickr({
                altInput: true,
                dateFormat: "Y-m-d",
                altFormat: "d/m/Y"
            });
            loanAccountSelect.on('change', function() {
                const accountId = $(this).val();
                const selectedOption = $(this).find('option:selected');
                currentDue = parseFloat(selectedOption.data('due') || 0);

                if (!accountId) { /* reset summary */ return; }
                summaryContent.html('<div class="spinner-border spinner-border-sm"></div>');

                $.ajax({
                    url: `/api/loan-accounts/${accountId}/details`,
                    type: 'GET',
                    success: function(response) {
                        const member = response.member;
                        const due = parseFloat(response.total_payable) - parseFloat(response.total_paid) - parseFloat(response.grace_amount);
                        let html = `
  <div class="text-center mb-3">
                            <img src="${member.photo_url}" class="rounded-circle" width="80" height="80" alt="Member Photo" style="object-fit: cover;">
                        </div>
                        <h6 class="text-center">${member.name}</h6>
                        <p class="text-muted text-center small mb-3">
                            <i data-lucide="phone" class="icon-sm me-1"></i> ${member.mobile_no}<br>
                            <i data-lucide="map-pin" class="icon-sm me-1"></i> ${member.address}
                        </p>                        <hr>
                        <h6 class="mb-3">Loan Details</h6>
                        <dl class="row">
                            <dt class="col-sm-5">Account No</dt><dd class="col-sm-7">${response.account_no}</dd>
                            <dt class="col-sm-5">Payable</dt><dd class="col-sm-7">${parseFloat(response.total_payable).toFixed(2)}</dd>
                            <dt class="col-sm-5">Paid</dt><dd class="col-sm-7">${parseFloat(response.total_paid).toFixed(2)}</dd>
                            <dt class="col-sm-5">Due</dt><dd class="col-sm-7 fw-bold text-danger">${due.toFixed(2)}</dd>
                            <dt class="col-sm-5">Installment</dt><dd class="col-sm-7">${parseFloat(response.installment_amount).toFixed(2)}</dd>
                        </dl>
                    `;
                        summaryContent.html(html);
                        paidAmountInput.val(response.installment_amount.toFixed(2));
                        paidAmountInput.trigger('input'); // Trigger input event to check for grace
                    }
                });
            });

            paidAmountInput.on('input', function() {
                const paidAmount = parseFloat($(this).val()) || 0;
                if (paidAmount >= currentDue && currentDue > 0) {
                    graceAmountWrapper.slideDown();
                } else {
                    graceAmountWrapper.slideUp();
                    graceAmountWrapper.find('input').val('');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/loan_installments/create.blade.php ENDPATH**/ ?>