<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.financial_summary')); ?></li>
        </ol>
    </nav>

    
    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"><?php echo e(__('messages.filter_summary_by_date')); ?></h6>
                    <form action="<?php echo e(route('admin.reports.financial_summary')); ?>" method="GET">
                        <div class="row">
                            <div class="col-md-5">
                                <label class="form-label"><?php echo e(__('messages.start_date')); ?></label>
                                <input type="date" name="start_date" class="form-control"
                                    value="<?php echo e($startDate ? $startDate->format('Y-m-d') : ''); ?>" required>
                            </div>
                            <div class="col-md-5">
                                <label class="form-label"><?php echo e(__('messages.end_date')); ?></label>
                                <input type="date" name="end_date" class="form-control"
                                    value="<?php echo e($endDate ? $endDate->format('Y-m-d') : ''); ?>" required>
                            </div>
                            <div class="col-md-2 d-flex align-items-end">
                                <button type="submit" class="btn btn-primary w-100"><?php echo e(__('messages.generate')); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

 <div class="row">
        
        <div class="col-lg-5 grid-margin stretch-card">
            <div class="card">
                <div class="card-header"><h5 class="card-title mb-0">Balance Sheet (as of <?php echo e(\Carbon\Carbon::today()->format('d M, Y')); ?>)</h5></div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <h6 class="text-primary border-bottom pb-2">Assets (সম্পদ)</h6>
                            <dl>
                                <dt>Cash & Bank</dt>
                                <dd><?php echo e(number_format($assets['cash_and_bank'], 2)); ?></dd>
                                <dt>Loan Principal on Field</dt>
                                <dd><?php echo e(number_format($assets['loan_principal_on_field'], 2)); ?></dd>
                            </dl>
                        </div>
                        <div class="col-6">
                            <h6 class="text-danger border-bottom pb-2">Liabilities & Equity (দায় ও সত্তা)</h6>
                             <dl>
                                <dt>Members' Savings</dt>
                                <dd><?php echo e(number_format($liabilities['members_savings'], 2)); ?></dd>
                                <dt>Capital Invested</dt>
                                <dd><?php echo e(number_format($equity['capital_invested'], 2)); ?></dd>
                                <dt>Retained Earnings</dt>
                                <dd><?php echo e(number_format($equity['retained_earnings'], 2)); ?></dd>
                            </dl>
                        </div>
                    </div>
                    <hr>
                    <div class="row fw-bold">
                        <div class="col-6"><p class="d-flex justify-content-between bg-light p-2 rounded"><span>Total Assets:</span> <span><?php echo e(number_format($assets['total'], 2)); ?></span></p></div>
                        <div class="col-6"><p class="d-flex justify-content-between bg-light p-2 rounded"><span>Total L & E:</span> <span><?php echo e(number_format($liabilities['total'] + $equity['total'], 2)); ?></span></p></div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-lg-7 grid-margin stretch-card">
            <div class="card">
                <div class="card-header"><h5 class="card-title mb-0">Income Statement (<?php echo e($startDate->format('d M')); ?> - <?php echo e($endDate->format('d M, Y')); ?>)</h5></div>
                <div class="card-body">
                    <h6 class="text-success border-bottom pb-2">Income (আয়)</h6>
                    <dl class="row">
                        <dt class="col-sm-8">Interest Earned from Loans</dt>
                        <dd class="col-sm-4 text-end"><?php echo e(number_format($income['interest_earned'], 2)); ?></dd>
                        
                    </dl>
                    <p class="d-flex justify-content-between bg-light p-2 rounded"><strong>Total Income:</strong> <strong><?php echo e(number_format($income['total'], 2)); ?></strong></p>

                    <h6 class="text-danger border-bottom pb-2 mt-4">Expenses (ব্যয়)</h6>
                    <dl class="row">
                        <dt class="col-sm-8">Profit Paid to Members</dt>
                        <dd class="col-sm-4 text-end"><?php echo e(number_format($expenses['profit_paid_to_members'], 2)); ?></dd>
                        <dt class="col-sm-8">Loan Grace / Discount Given</dt>
                        <dd class="col-sm-4 text-end"><?php echo e(number_format($expenses['loan_grace_given'], 2)); ?></dd>
                        <dt class="col-sm-8">Salary Expenses</dt>
                        <dd class="col-sm-4 text-end"><?php echo e(number_format($expenses['salary_expenses'], 2)); ?></dd>
                        <dt class="col-sm-8">Operational Expenses</dt>
                        <dd class="col-sm-4 text-end"><?php echo e(number_format($expenses['operational_expenses'], 2)); ?></dd>
                    </dl>
                    <p class="d-flex justify-content-between bg-light p-2 rounded"><strong>Total Expenses:</strong> <strong><?php echo e(number_format($expenses['total'], 2)); ?></strong></p>

                    <hr>
                    <div class="text-center mt-3">
                        <h5>Net Profit / Loss</h5>
                        <h3 class="<?php echo e($netProfitLoss >= 0 ? 'text-success' : 'text-danger'); ?>"><?php echo e(number_format($netProfitLoss, 2)); ?></h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/admin/reports/financial_summary.blade.php ENDPATH**/ ?>