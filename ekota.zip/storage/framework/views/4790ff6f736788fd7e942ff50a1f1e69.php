<footer class="footer d-flex flex-column flex-md-row align-items-center justify-content-between px-4 py-3 border-top small">
  <p class="text-secondary mb-1 mb-md-0">Copyright © 2025 <a href="#" target="_blank">Ekota</a>.</p>
  <p class="text-secondary">Umairit.com <i class="mb-1 text-primary ms-1 icon-sm" data-lucide="heart"></i></p>
</footer>
<?php /**PATH C:\wamp64\www\ekota\resources\views/layout/partials/footer.blade.php ENDPATH**/ ?>