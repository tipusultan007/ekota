<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
    <ol class="breadcrumb">
        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard')); ?>"><?php echo e(__('messages.dashboard')); ?></a></li>
        <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.todays_worklist')); ?> (<?php echo e(\Carbon\Carbon::today()->format('d M, Y')); ?>)</li>
    </ol>
    </nav>

    <div class="row">
        
        <div class="col-md-12 grid-margin">
            <div class="card">
                <div class="card-header bg-primary">
                    <h5 class="card-title mb-0 text-white  "><?php echo e(__('messages.todays_summary_and_targets')); ?></h5>
                </div>
                <div class="card-body">

                    <div class="row text-center">
                        <div class="col-md-4">
                            <div class="card-title  "><?php echo e(__('messages.outstanding_loan_installments')); ?></div>
                            <h4 class="text-danger"><?php echo e($loanInstallmentsDueToday->count()); ?> <?php echo e(__('messages.accounts')); ?></h4>
                        </div>
                        <div class="col-md-4">
                            <div class="card-title  "><?php echo e(__('messages.outstanding_savings_collections')); ?></div>
                            <h4 class="text-success"><?php echo e($savingsDueToday->count()); ?> <?php echo e(__('messages.accounts')); ?></h4>
                        </div>
                        <div class="col-md-4">
                            <div class="card-title  "><?php echo e(__('messages.todays_loan_collection_target')); ?></div>
                            <h4 class="text-primary"><?php echo e(number_format($totalTarget, 2)); ?> BDT</h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-header bg-danger">
                    <h6 class="card-title text-white mb-0 "><?php echo e(__('messages.loan_installments_due')); ?></h6>
                </div>
                <div class="card-body">

                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                            <tr>
                                <th class="  "><?php echo e(__('messages.member')); ?></th>
                                <th class="  "><?php echo e(__('messages.due_date')); ?></th>
                                <th class="text-end  "><?php echo e(__('messages.amount')); ?></th>
                                <th class="  "><?php echo e(__('messages.action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $loanInstallmentsDueToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $loan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="">
                                        <a href="<?php echo e(route('members.show', $loan->member->id)); ?>"><?php echo e($loan->member->name); ?></a>
                                        <br><small><?php echo e($loan->member->mobile_no); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger"><?php echo e(\Carbon\Carbon::parse($loan->next_due_date)->format('d M, Y')); ?></span>
                                    </td>
                                    <td class="text-end "><?php echo e(number_format($loan->installment_amount, 2)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('loan-accounts.show',$loan->id)); ?>" class="btn btn-primary btn-xs fw-bolder"><?php echo e(__('messages.collect')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted"><?php echo e(__('messages.no_outstanding_loan_installments')); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-lg-6 grid-margin stretch-card">
            <div class="card">
                <div class="card-header bg-success">
                    <h6 class="card-title text-white mb-0 "><?php echo e(__('messages.savings_collections_due')); ?></h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm table-hover">
                            <thead>
                            <tr>
                                <th class="  "><?php echo e(__('messages.member')); ?></th>
                                <th class="  "><?php echo e(__('messages.due_date')); ?></th>
                                <th class="text-end  "><?php echo e(__('messages.scheme')); ?></th>
                                <th class="  "><?php echo e(__('messages.action')); ?></th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $savingsDueToday; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saving): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td class="">
                                        <a href="<?php echo e(route('members.show', $saving->member->id)); ?>"><?php echo e($saving->member->name); ?></a>
                                        <br><small><?php echo e($saving->member->mobile_no); ?></small>
                                    </td>
                                    <td>
                                        <span class="badge bg-danger"><?php echo e(\Carbon\Carbon::parse($saving->next_due_date)->format('d M, Y')); ?></span>
                                    </td>
                                    <td class="text-end"><?php echo e(__('messages.'.$saving->scheme_type)); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('savings-accounts.show',$saving->id)); ?>" class="btn btn-primary btn-xs fw-bolder"><?php echo e(__('messages.collect')); ?></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="4" class="text-center text-muted"><?php echo e(__('messages.no_outstanding_savings_collections')); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/worklist/today.blade.php ENDPATH**/ ?>