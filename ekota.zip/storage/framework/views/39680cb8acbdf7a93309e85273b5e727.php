<nav class="navbar">
  <div class="navbar-content">

    <div class="logo-mini-wrapper">
      <img src="<?php echo e(url('build/images/logo-mini-light.png')); ?>" class="logo-mini logo-mini-light" alt="logo">
      <img src="<?php echo e(url('build/images/logo-mini-dark.png')); ?>" class="logo-mini logo-mini-dark" alt="logo">
    </div>

    <form class="search-form">
      <div class="input-group">
        <div class="input-group-text">
          <i data-lucide="search"></i>
        </div>
        <input type="text" class="form-control" id="navbarForm" placeholder="Search here...">
      </div>
    </form>

    <ul class="navbar-nav">
      <li class="theme-switcher-wrapper nav-item">
        <input type="checkbox" value="" id="theme-switcher">
        <label for="theme-switcher">
          <div class="box">
            <div class="ball"></div>
            <div class="icons">
              <i class="link-icon" data-lucide="sun"></i>
              <i class="link-icon" data-lucide="moon"></i>
            </div>
          </div>
        </label>
      </li>
        
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle d-flex" href="#" id="languageDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">

                <?php if(session()->get('locale') == 'bn'): ?>
                    <img src="<?php echo e(url('build/images/flags/bd.svg')); ?>" class="w-20px" title="bn" alt="flag">
                    <span class="ms-2 d-none d-md-inline-block">বাংলা</span>
                <?php else: ?>
                    <img src="<?php echo e(url('build/images/flags/us.svg')); ?>" class="w-20px" title="us" alt="flag">
                    <span class="ms-2 d-none d-md-inline-block">English</span>
                <?php endif; ?>

            </a>
            <div class="dropdown-menu" aria-labelledby="languageDropdown">
                
                <form action="<?php echo e(route('language.switch')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="lang" value="en">
                    <button type="submit" class="dropdown-item py-2 d-flex border-0 bg-transparent">
                        <img src="<?php echo e(url('build/images/flags/us.svg')); ?>" class="w-20px" title="us" alt="us">
                        <span class="ms-2"> English </span>
                    </button>
                </form>

                
                <form action="<?php echo e(route('language.switch')); ?>" method="POST" class="d-inline">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="lang" value="bn">
                    <button type="submit" class="dropdown-item py-2 d-flex border-0 bg-transparent">
                        <img src="<?php echo e(url('build/images/flags/bd.svg')); ?>" class="w-20px" title="bn" alt="bn">
                        <span class="ms-2"> বাংলা </span>
                    </button>
                </form>
            </div>
        </li>

      
        
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="profileDropdown" role="button" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                <img class="w-30px h-30px ms-1 rounded-circle" src="<?php echo e(url('https://placehold.co/30x30')); ?>" alt="profile">
            </a>
            <div class="dropdown-menu p-0" aria-labelledby="profileDropdown">
                <div class="d-flex flex-column align-items-center border-bottom px-5 py-3">
                    <div class="mb-3">
                        <img class="w-80px h-80px rounded-circle" src="<?php echo e(url('https://placehold.co/80x80')); ?>" alt="">
                    </div>
                    <div class="text-center">
                        <p class="fs-16px fw-bolder"><?php echo e(auth()->user()->name); ?></p>
                        <p class="fs-12px text-secondary"><?php echo e(auth()->user()->email); ?></p>
                    </div>
                </div>
                <ul class="list-unstyled p-1">
                    <li>
                        
                        <a href="<?php echo e(route('profile.edit')); ?>" class="dropdown-item py-2 text-body ms-0">
                            <i class="me-2 icon-md" data-lucide="user"></i>
                            <span>Profile</span>
                        </a>
                    </li>
                    <li>
                        <!-- Logout Form -->
                        <form method="POST" action="<?php echo e(route('logout')); ?>">
                            <?php echo csrf_field(); ?>
                            <a href="<?php echo e(route('logout')); ?>" class="dropdown-item py-2 text-body ms-0"
                               onclick="event.preventDefault(); this.closest('form').submit();">
                                <i class="me-2 icon-md" data-lucide="log-out"></i>
                                <span><?php echo e(__('Log Out')); ?></span>
                            </a>
                        </form>
                    </li>
                </ul>
            </div>
        </li>
    </ul>

    <a href="#" class="sidebar-toggler">
      <i data-lucide="menu"></i>
    </a>

  </div>
</nav>
<?php /**PATH C:\wamp64\www\ekota\resources\views/layout/partials/header.blade.php ENDPATH**/ ?>