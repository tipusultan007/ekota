<?php $__env->startPush('plugin-styles'); ?>
    <style>
        /* Card Gradient Styles */
        .card-gradient-info { background: linear-gradient(to right, #4e54c8, #8f94fb); color: white; }
        .card-gradient-success { background: linear-gradient(to right, #1d976c, #93f9b9); color: white; }
        .card-gradient-danger { background: linear-gradient(to right, #cb2d3e, #ef473a); color: white; }
        .card-gradient-warning { background: linear-gradient(to right, #ff8008, #ffc837); color: white; }
        .card-gradient-primary { background: linear-gradient(to right, #00c6ff, #0072ff); color: white; }
        .card-gradient-dark { background: linear-gradient(to right, #434343, #000000); color: white; }

        .card[class*="card-gradient-"] h1,
        .card[class*="card-gradient-"] h2,
        .card[class*="card-gradient-"] h3,
        .card[class*="card-gradient-"] h4,
        .card[class*="card-gradient-"] h5,
        .card[class*="card-gradient-"] h6,
        .card[class*="card-gradient-"] .text-muted {
            color: rgba(255, 255, 255, 0.9);
        }
        .card[class*="card-gradient-"] .small {
            color: rgba(255, 255, 255, 0.8);
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
    <div class="d-flex justify-content-between align-items-center flex-wrap grid-margin">
        <div>
            <h4 class="mb-3  mb-md-0"><?php echo e(__('messages.welcome_to_admin_dashboard')); ?></h4>
        </div>
    </div>

    
    <div class="row">
        <div class="col-md-4 col-lg-2 grid-margin stretch-card">
            <div class="card card-gradient-primary">
                <div class="card-body text-center">
                    <h5 class="text-uppercase"><?php echo e(__('messages.total_members')); ?></h5>
                    <h4 class="mb-0"><?php echo e($totalMembers); ?></h4>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2 grid-margin stretch-card">
            <div class="card card-gradient-success">
                <div class="card-body text-center">
                    <h5 class="text-uppercase"><?php echo e(__('messages.withdrawable_savings')); ?></h5>
                    <h4 class="mb-0"><?php echo e(number_format($withdrawableAmount)); ?></h4>
                    <small><?php echo e(__('messages.total_savings_balance')); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2 grid-margin stretch-card">
            <div class="card card-gradient-danger">
                <div class="card-body text-center">
                    <h5 class="text-uppercase"><?php echo e(__('messages.total_withdrawn')); ?></h5>
                    <h4 class="mb-0"><?php echo e(number_format($totalWithdrawn)); ?></h4>
                    <small><?php echo e(__('messages.all_time')); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2 grid-margin stretch-card">
            <div class="card card-gradient-info">
                <div class="card-body text-center">
                    <h5 class="text-uppercase"><?php echo e(__('messages.loan_disbursed')); ?></h5>
                    <h4 class="mb-0"><?php echo e(number_format($totalLoanDisbursed)); ?></h4>
                    <small><?php echo e(__('messages.all_time')); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2 grid-margin stretch-card">
            <div class="card card-gradient-warning">
                <div class="card-body text-center">
                    <h5 class="text-uppercase"><?php echo e(__('messages.loan_on_field')); ?></h5>
                    <h4 class="mb-0"><?php echo e(number_format($totalLoanDue)); ?></h4>
                    <small><?php echo e(__('messages.total_due')); ?></small>
                </div>
            </div>
        </div>
        <div class="col-md-4 col-lg-2 grid-margin stretch-card">
            <div class="card card-gradient-dark">
                <div class="card-body text-center">
                    <h5 class="text-uppercase"><?php echo e(__('messages.net_position')); ?></h5>
                    <?php
                        $netPosition = $withdrawableAmount - $totalLoanDue;
                    ?>
                    <h4 class="mb-0 <?php echo e($netPosition >= 0 ? '' : 'text-danger'); ?>">
                        <?php echo e(number_format($netPosition)); ?>

                    </h4>
                    <small class="text-light"><?php echo e(__('messages.savings_vs_due')); ?></small>
                </div>
            </div>
        </div>
    </div>

    
    <div class="row">
        
        <div class="col-lg-5 col-xl-4 grid-margin stretch-card">
            <div class="card">
                <div class="card-header">
                    <h4 class="card-title mb-0  "><?php echo e(__('messages.todays_statistics')); ?>

                        (<?php echo e(\Carbon\Carbon::today()->format('d M, Y')); ?>)</h4>
                </div>
                <div class="card-body">

                    <div class="list-group list-group-flush">
                        <div class="list-group-item d-flex justify-content-between">
                            <span class="text-success "><?php echo e(__('messages.savings_collection')); ?></span>
                            <span class="fw-bold text-success">+ <?php echo e(number_format($todaySavings)); ?></span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span class="text-primary "><?php echo e(__('messages.loan_collection')); ?></span>
                            <span class="fw-bold text-primary">+ <?php echo e(number_format($todayInstallments)); ?></span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span class="text-danger "><?php echo e(__('messages.savings_withdrawal')); ?></span>
                            <span class="fw-bold text-danger">- <?php echo e(number_format($todayWithdrawals)); ?></span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between">
                            <span class="text-warning "><?php echo e(__('messages.other_expenses')); ?></span>
                            <span class="fw-bold text-warning">- <?php echo e(number_format($todayExpenses)); ?></span>
                        </div>
                        <div class="list-group-item d-flex justify-content-between bg-light">
                            <?php
                                $netCashFlow = ($todaySavings + $todayInstallments) - ($todayWithdrawals + $todayExpenses);
                            ?>
                           <span class=""> <strong><?php echo e(__('messages.net_cash_flow')); ?></strong></span>
                            <strong class="<?php echo e($netCashFlow >= 0 ? 'text-success' : 'text-danger'); ?>">
                                <?php echo e(number_format($netCashFlow)); ?>

                            </strong>
                        </div>
                    </div>

                    <hr>
                    <h6 class="card-title   mt-4"><?php echo e(__('messages.members_by_area')); ?></h6>
                    <div id="areaPieChart"></div>
                </div>
            </div>
        </div>

        
        <div class="col-lg-7 col-xl-8 grid-margin stretch-card">
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title  mb-0 "><?php echo e(__('messages.monthly_collection_last_6_months')); ?></h5>
                </div>
                <div class="card-body">

                    <div id="monthlyCollectionChart"></div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php $__env->startPush('plugin-scripts'); ?>
    <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('custom-scripts'); ?>
    <script>
        // Monthly Collection Bar Chart
        var optionsBar = {
            chart: {type: 'bar', height: 350},
            series: [
                {name: "<?php echo e(__('messages.savings')); ?>", data: <?php echo json_encode($monthlyCollections['savings'], 15, 512) ?> },
                {name: "<?php echo e(__('messages.loans')); ?>", data: <?php echo json_encode($monthlyCollections['loans'], 15, 512) ?> }
            ],
            xaxis: {categories: <?php echo json_encode($monthlyCollections['months'], 15, 512) ?> }
        };
        var chartBar = new ApexCharts(document.querySelector("#monthlyCollectionChart"), optionsBar);
        chartBar.render();

        // Area wise Members Pie Chart
        var optionsPie = {
            chart: {type: 'pie', height: 250},
            series: <?php echo json_encode($areaWiseMembers->pluck('count'), 15, 512) ?>,
            labels: <?php echo json_encode($areaWiseMembers->pluck('name'), 15, 512) ?>,
            responsive: [{
                breakpoint: 480,
                options: {
                    chart: {
                        width: 200
                    },
                    legend: {
                        position: 'bottom'
                    }
                }
            }]
        };
        var chartPie = new ApexCharts(document.querySelector("#areaPieChart"), optionsPie);
        chartPie.render();
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/dashboard/admin.blade.php ENDPATH**/ ?>