<?php $__env->startSection('content'); ?>
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('loan_accounts.index')); ?>"><?php echo e(__('messages.loan_accounts')); ?></a></li>
            <li class="breadcrumb-item active" aria-current="page"><?php echo e(__('messages.account_details')); ?></li>
        </ol>
    </nav>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <div class="row">
        
        <div class="col-12 grid-margin">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center">
                        
                        <div class="mb-3 mb-md-0">
                            <h5 class="card-title"><?php echo e(__('messages.loan_summary')); ?>: <?php echo e($loanAccount->account_no); ?></h5>
                            <p class="text-muted mb-0">
                                <?php echo e(__('messages.member')); ?>: <a href="<?php echo e(route('members.show', $loanAccount->member_id)); ?>"><?php echo e($loanAccount->member->name); ?></a>
                            </p>
                        </div>

                        
                        <div class="d-flex align-items-center">
                            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                            <?php if($loanAccount->status == 'running' && ($loanAccount->total_payable - $loanAccount->total_paid) > 0): ?>
                                <button type="button" class="btn btn-success btn-sm me-2" data-bs-toggle="modal"
                                        data-bs-target="#payOffModal">
                                    <i data-lucide="check-circle" class="icon-sm me-1"></i> <?php echo e(__('messages.pay_off_loan')); ?>

                                </button>
                            <?php endif; ?>
                            <?php endif; ?>
                            <span class="badge bg-<?php echo e($loanAccount->status == 'running' ? 'warning' : ($loanAccount->status == 'paid' ? 'success' : 'danger')); ?>" style="font-size: 0.9rem;">
                            <?php echo e(ucfirst($loanAccount->status)); ?>

                        </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row g-2">
        <div class="col-md-2 col-6 grid-margin">
            <div class="card bg-primary text-white">
                <div class="card-body text-center">
                    <p class="text-muted mb-1 small"><?php echo e(__('messages.loan_amount')); ?></p>
                    <h5 class="mb-0"><?php echo e(number_format($loanAccount->loan_amount, 2)); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-2 col-6 grid-margin">
            <div class="card bg-light">
                <div class="card-body text-center">
                    <p class="text-muted mb-1 small"><?php echo e(__('messages.total_installments')); ?></p>
                    <h5 class="mb-0"><?php echo e($loanAccount->number_of_installments); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-2 col-6 grid-margin">
            <div class="card bg-info">
                <div class="card-body text-center">
                    <p class="text-muted mb-1 small"><?php echo e(__('messages.total_payable')); ?></p>
                    <h5 class="mb-0"><?php echo e(number_format($loanAccount->total_payable, 2)); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-2 col-6 grid-margin">
            <div class="card bg-success text-white">
                <div class="card-body text-center">
                    <p class="mb-1 small"><?php echo e(__('messages.total_paid')); ?></p>
                    <h5 class="mb-0"><?php echo e(number_format($loanAccount->total_paid, 2)); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-2 col-6 grid-margin">
            <div class="card bg-warning text-dark">
                <div class="card-body text-center">
                    <p class="mb-1 small"><?php echo e(__('messages.grace_amount')); ?></p>
                    <h5 class="mb-0"><?php echo e(number_format($loanAccount->grace_amount, 2)); ?></h5>
                </div>
            </div>
        </div>

        <div class="col-md-2 col-6 grid-margin">
            <div class="card bg-danger text-white">
                <div class="card-body text-center">
                    <p class="mb-1 small"><?php echo e(__('messages.due_amount')); ?></p>
                    <h5 class="mb-0"><?php echo e(number_format($loanAccount->total_payable - $loanAccount->total_paid - $loanAccount->grace_amount, 2)); ?></h5>
                </div>
            </div>
        </div>
    </div>

    <div class="row">
        
        <div class="col-md-5 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title"><?php echo e(__('messages.guarantor_information')); ?></h6>
                    <?php if($loanAccount->guarantor): ?>
                        <?php if($loanAccount->guarantor->member): ?>
                            <p><strong><?php echo e(__('messages.existing_member')); ?></strong></p>
                            <p><strong><?php echo e(__('messages.member')); ?>:</strong> <a href="<?php echo e(route('members.show', $loanAccount->guarantor->member->id)); ?>"><?php echo e($loanAccount->guarantor->member->name); ?></a></p>
                            <p><strong>Phone:</strong> <?php echo e($loanAccount->guarantor->member->mobile_no); ?></p>
                        <?php else: ?>
                            <p><strong><?php echo e(__('messages.outside_person')); ?></strong></p>
                            <p><strong><?php echo e(__('messages.member')); ?>:</strong> <?php echo e($loanAccount->guarantor->name); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($loanAccount->guarantor->phone); ?></p>
                            <p><strong>Address:</strong> <?php echo e($loanAccount->guarantor->address); ?></p>
                        <?php endif; ?>
                        <hr>
                        <p><strong><?php echo e(__('messages.loan_documents')); ?></strong></p>
                    <?php else: ?>
                        <p class="text-muted">No guarantor information found.</p>
                    <?php endif; ?>

                    <ul class="list-unstyled">
                        <?php $__empty_1 = true; $__currentLoopData = $loanAccount->getMedia('loan_documents'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $media): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <li><a href="<?php echo e($media->getUrl()); ?>" target="_blank"><?php echo e($media->getCustomProperty('document_name', $media->name)); ?></a></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <li>No documents uploaded.</li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </div>

        
        <div class="col-md-7">
            <?php if($loanAccount->status != 'paid'): ?>
                <div class="card my-3">
                    <div class="card-header bg-primary">
                        <h5 class="card-title mb-0 text-white"><?php echo e(__('messages.make_new_loan_collection')); ?></h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('loan-installments.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="loan_account_id" value="<?php echo e($loanAccount->id); ?>">
                            <div class="row">
                                <div class="col-md-4 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.payment_date')); ?></label>
                                    <input type="text" name="payment_date" class="form-control flatpickr" value="<?php echo e(date('Y-m-d')); ?>" required>
                                </div>
                                <div class="col-md-4 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.amount')); ?> <span class="text-danger">*</span></label>
                                    <input type="number" step="0.01" name="paid_amount" id="paid_amount_input" class="form-control" required>
                                </div>
                                <div class="col-md-4 mb-3" id="grace_amount_wrapper">
                                    <label class="form-label"><?php echo e(__('messages.grace_amount')); ?></label>
                                    <input type="number" step="0.01" name="grace_amount" id="grace_amount_input" class="form-control" placeholder="0.00">
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.deposit_to')); ?> <span class="text-danger">*</span></label>
                                    <select name="account_id" class="form-select" required>
                                        <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-12 mb-3">
                                    <label class="form-label"><?php echo e(__('messages.notes')); ?></label>
                                    <textarea name="notes" class="form-control" rows="2"></textarea>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary"><?php echo e(__('messages.submit_installment')); ?></button>
                        </form>
                    </div>
                </div>
            <?php endif; ?>

            <div class="card">
                <div class="card-header bg-success">
                    <h6 class="card-title mb-0 text-white"><?php echo e(__('messages.installment_history')); ?></h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                            <tr>
                                <th><?php echo e(__('messages.payment_date')); ?></th>
                                <th><?php echo e(__('messages.amount')); ?></th>
                                <th><?php echo e(__('messages.grace_amount')); ?></th>
                                <th><?php echo e(__('messages.member')); ?></th>
                                <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                                <th class="text-center"><?php echo e(__('messages.actions')); ?></th>
                                <?php endif; ?>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $loanAccount->installments->sortByDesc('payment_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $installment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($installment->payment_date->format('d M, Y')); ?></td>
                                    <td><?php echo e(number_format($installment->paid_amount, 2)); ?></td>
                                    <td><?php echo e(number_format($installment->grace_amount, 2)); ?></td>
                                    <td><?php echo e($installment->collector->name ?? 'N/A'); ?></td>
                                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                                    <td class="text-center">
                                        <div class="d-inline-flex">
                                            <a href="<?php echo e(route('loan-installments.edit', $installment->id)); ?>" class="btn btn-primary btn-xs me-1" title="<?php echo e(__('messages.actions')); ?>">
                                                <i data-lucide="edit" class="icon-xs"></i>
                                            </a>
                                            <form id="delete-installment-<?php echo e($installment->id); ?>" action="<?php echo e(route('loan-installments.destroy', $installment->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="button" class="btn btn-danger btn-xs" title="<?php echo e(__('messages.actions')); ?>" onclick="showDeleteConfirm('delete-installment-<?php echo e($installment->id); ?>')">
                                                    <i data-lucide="trash-2" class="icon-xs"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="<?php echo e(Auth::user()->hasRole('Admin') ? '5' : '4'); ?>" class="text-center"><?php echo e(__('messages.no_installments')); ?></td>
                                </tr>
                            <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    
    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
    <div class="modal fade" id="payOffModal" tabindex="-1" aria-labelledby="payOffModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="payOffModalLabel"><?php echo e(__('messages.confirm_loan_pay_off')); ?></h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo e(route('admin.loan_accounts.pay_off', $loanAccount->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <p><?php echo e(__('messages.confirm_pay_off_text')); ?></p>
                        <div class="alert alert-secondary">
                            <div class="d-flex justify-content-between">
                                <span><?php echo e(__('messages.remaining_due')); ?></span>
                                <strong id="dueAmountDisplay"><?php echo e(number_format($loanAccount->total_payable - $loanAccount->total_paid, 2)); ?></strong>
                            </div>
                            <hr class="my-2">
                            <div class="d-flex justify-content-between">
                                <span><?php echo e(__('messages.final_amount_to_collect')); ?></span>
                                <strong id="finalPaymentDisplay" class="text-success" style="font-size: 1.2rem;"><?php echo e(number_format($loanAccount->total_payable - $loanAccount->total_paid, 2)); ?></strong>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="grace_amount" class="form-label"><?php echo e(__('messages.grace_amount')); ?> (<?php echo e(__('messages.discount')); ?>)</label>
                            <input type="number" step="0.01" name="grace_amount" id="grace_amount_input" class="form-control" placeholder="0.00">
                        </div>
                        <div class="mb-3">
                            <label for="account_id" class="form-label"><?php echo e(__('messages.deposit_to')); ?> <span class="text-danger">*</span></label>
                            <select name="account_id" class="form-select" required>
                                <option value=""><?php echo e(__('messages.select_account')); ?></option>
                                <?php $__currentLoopData = \App\Models\Account::where('is_active', true)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($account->id); ?>"><?php echo e($account->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="payment_date" class="form-label"><?php echo e(__('messages.payment_date')); ?> <span class="text-danger">*</span></label>
                            <input type="date" name="payment_date" class="form-control" value="<?php echo e(date('Y-m-d')); ?>" required>
                        </div>
                        <div class="mb-3">
                            <label for="notes" class="form-label"><?php echo e(__('messages.notes')); ?> (<?php echo e(__('messages.optional')); ?>)</label>
                            <textarea name="notes" class="form-control" rows="2" placeholder="<?php echo e(__('messages.notes_placeholder')); ?>"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"><?php echo e(__('messages.cancel')); ?></button>
                        <button type="submit" class="btn btn-success"><?php echo e(__('messages.confirm_and_pay_off')); ?></button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-scripts'); ?>
    <script>
        $(".flatpickr").flatpickr({
            altInput: true,
            dateFormat: 'Y-m-d',
            altFormat: 'd/m/Y'
        })
    </script>
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const payOffModal = document.getElementById('payOffModal');
            if (payOffModal) {
                const dueAmount = parseFloat(<?php echo e($loanAccount->total_payable - $loanAccount->total_paid); ?>);
                const graceInput = payOffModal.querySelector('#grace_amount_input');
                const finalPaymentDisplay = payOffModal.querySelector('#finalPaymentDisplay');

                graceInput.addEventListener('input', function () {
                    let grace = parseFloat(this.value) || 0;
                    if (grace > dueAmount) {
                        grace = dueAmount;
                        this.value = dueAmount.toFixed(2);
                    }
                    let finalPayment = dueAmount - grace;
                    finalPaymentDisplay.textContent = finalPayment.toFixed(2);
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/loan_accounts/show.blade.php ENDPATH**/ ?>