<?php $__env->startPush('plugin-styles'); ?>
    <link rel="stylesheet" href="<?php echo e(asset('build/plugins/select2/select2.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('build/plugins/flatpickr/flatpickr.min.css')); ?>">
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card my-3">
        <div class="card-body">
            <form action="<?php echo e(route('loan_accounts.index')); ?>" method="GET" class="mb-4">
                <div class="row">
                    <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                    <div class="col-md-3 mb-2"><select name="area_id" class="form-select">
                            <option value=""><?php echo e(__('messages.all_areas')); ?></option><?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($area->id); ?>" <?php echo e(request('area_id') == $area->id ? 'selected' : ''); ?>><?php echo e($area->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <?php endif; ?>
                    <div class="col-md-3 mb-2"><select name="member_id" id="member_id" class="form-select" data-allow-clear="on">
                            <option value=""><?php echo e(__('messages.all_members')); ?></option><?php $__currentLoopData = $members; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $member): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option
                                    value="<?php echo e($member->id); ?>" <?php echo e(request('member_id') == $member->id ? 'selected' : ''); ?>><?php echo e($member->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select></div>
                    <div class="col-md-2 mb-2"><select name="status" class="form-select">
                            <option value=""><?php echo e(__('messages.all_status')); ?></option>
                            <option value="running" <?php echo e(request('status') == 'running' ? 'selected' : ''); ?>><?php echo e(__('messages.running')); ?></option>
                            <option value="paid" <?php echo e(request('status') == 'paid' ? 'selected' : ''); ?>><?php echo e(__('messages.paid')); ?></option>
                            <option value="defaulted" <?php echo e(request('status') == 'defaulted' ? 'selected' : ''); ?>><?php echo e(__('messages.defaulted')); ?></option>
                        </select></div>
                    <div class="col-md-2 mb-2"><input type="text" name="start_date" class="form-control flatpickr"
                                                      value="<?php echo e(request('start_date')); ?>" placeholder="<?php echo e(__('messages.start_date')); ?>"></div>
                    <div class="col-md-2 mb-2"><input type="text" name="end_date" class="form-control flatpickr"
                                                      value="<?php echo e(request('end_date')); ?>" placeholder="<?php echo e(__('messages.end_date')); ?>"></div>
                    <div class="col-md-12 mt-2">
                        <button type="submit" class="btn btn-primary"><?php echo e(__('messages.filter')); ?></button>
                        <a href="<?php echo e(route('loan_accounts.index')); ?>" class="btn btn-secondary"><?php echo e(__('messages.reset')); ?></a></div>
                </div>
            </form>
        </div>
    </div>
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <h5 class="card-title mb-0"><?php echo e(__('messages.loan_accounts_list')); ?></h5>
            <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                <a href="<?php echo e(route('loan.new')); ?>" class="btn btn-primary"><?php echo e(__('messages.new_loan_application')); ?></a>
            <?php endif; ?>
        </div>
        <div class="card-body ">

            <div class="table-responsive min-vh-100">
                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th><?php echo e(__('messages.account_no')); ?></th>
                        <th><?php echo e(__('messages.member')); ?></th>
                        <th><?php echo e(__('messages.area')); ?></th>
                        <th class="text-end"><?php echo e(__('messages.loan_amount')); ?></th>
                        <th class="text-end"><?php echo e(__('messages.paid')); ?></th>
                        <th class="text-end"><?php echo e(__('messages.grace')); ?></th>
                        <th class="text-end"><?php echo e(__('messages.due')); ?></th>
                        <th><?php echo e(__('messages.status')); ?></th>
                        <th><?php echo e(__('messages.disbursement_date')); ?></th>
                        <th><?php echo e(__('messages.actions')); ?></th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $loanAccounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><a href="<?php echo e(route('loan_accounts.show', $account->id)); ?>"><?php echo e($account->account_no); ?></a></td>
                            <td><?php echo e($account->member->name); ?></td>
                            <td><?php echo e($account->member->area->name); ?></td>
                            <td class="text-end"><?php echo e(number_format($account->loan_amount, 2)); ?></td>
                            <td class="text-end text-success"><?php echo e(number_format($account->total_paid, 2)); ?></td>
                            <td class="text-end text-primary"><?php echo e(number_format($account->grace_amount, 2)); ?></td>
                            <td class="text-end text-danger"><?php echo e(number_format($account->loan_due_amount, 2)); ?></td>
                            <td>
                                <?php
                                    $statusClass = 'danger';
                                    if ($account->status == 'running') $statusClass = 'warning';
                                    elseif ($account->status == 'paid') $statusClass = 'success';
                                ?>
                                <span class="badge bg-<?php echo e($statusClass); ?>"><?php echo e(__( 'messages.' . strtolower($account->status) )); ?></span>
                            </td>
                            <td><?php echo e($account->disbursement_date->format('d M, Y')); ?></td>
                            <td>
                                <div class="dropdown">
                                    <button class="btn btn-secondary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton-loan-<?php echo e($account->id); ?>" data-bs-toggle="dropdown" aria-expanded="false">
                                        <?php echo e(__('messages.actions')); ?>

                                    </button>
                                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton-loan-<?php echo e($account->id); ?>">
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('loan_accounts.show', $account->id)); ?>">
                                                <i data-lucide="eye" class="icon-sm me-2"></i> <?php echo e(__('messages.view_details')); ?>

                                            </a>
                                        </li>
                                        <?php if (\Illuminate\Support\Facades\Blade::check('role', 'Admin')): ?>
                                        <li>
                                            <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('loan-accounts.edit', $account->id)); ?>">
                                                <i data-lucide="edit" class="icon-sm me-2"></i> <?php echo e(__('messages.edit_account')); ?>

                                            </a>
                                        </li>
                                        <?php if($account->status == 'running'): ?>
                                            <li>
                                                <a class="dropdown-item d-flex align-items-center" href="<?php echo e(route('loan_accounts.show', $account->id)); ?>">
                                                    <i data-lucide="check-circle" class="icon-sm me-2"></i> <?php echo e(__('messages.pay_off')); ?>

                                                </a>
                                            </li>
                                        <?php endif; ?>
                                        <li><hr class="dropdown-divider"></li>
                                        <li>
                                            <form id="delete-loan-account-<?php echo e($account->id); ?>" action="<?php echo e(route('loan-accounts.destroy', $account->id)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>

                                                <button type="button" class="dropdown-item d-flex align-items-center text-danger" onclick="showDeleteConfirm('delete-loan-account-<?php echo e($account->id); ?>')">
                                                    <i data-lucide="trash-2" class="icon-sm me-2"></i> <?php echo e(__('messages.delete_account')); ?>

                                                </button>
                                            </form>
                                        </li>
                                        <?php endif; ?>
                                    </ul>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="9" class="text-center"><?php echo e(__('messages.no_loan_accounts_found')); ?></td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
            <div class="mt-4"><?php echo e($loanAccounts->appends(request()->query())->links()); ?></div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('plugin-scripts'); ?>
    <script src="<?php echo e(asset('build/plugins/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('build/plugins/select2/select2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('build/plugins/flatpickr/flatpickr.min.js')); ?>"></script>
    <script>
        $('#member_id').select2({placeholder: "<?php echo e(__('messages.select_member')); ?>", width: '100%'});
        $(".flatpickr").flatpickr({
            altInput: true,
            dateFormat: 'Y-m-d',
            altFormat: 'd/m/Y',
        })
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layout.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\wamp64\www\ekota\resources\views/loan_accounts/index.blade.php ENDPATH**/ ?>