@extends('layout.master2')
@section('content')
    <h1>Hello</h1>
@endsection
