// npm package: inputmask
// github link: https://github.com/RobinHerbots/Inputmask

'use strict';

(function () {

  // initializing inputmask
  $('input[data-inputmask]').inputmask();

})();