@extends('layout.master')

@section('content')
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('admin.areas.index') }}">{{ __('messages.area_list') }}</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ __('messages.edit_area') }}</li>
        </ol>
    </nav>

    <div class="row">
        <div class="col-md-8 mx-auto grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <h6 class="card-title">{{ __('messages.edit_area') }}: {{ $area->name }}</h6>
                    <form action="{{ route('admin.areas.update', $area) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <div class="mb-3">
                            <label for="name" class="form-label">{{ __('messages.area_name') }}</label>
                            <input type="text" class="form-control @error('name') is-invalid @enderror" id="name" name="name" value="{{ old('name', $area->name) }}">
                            @error('name')
                            <span class="invalid-feedback" role="alert">
                                <strong>{{ $message }}</strong>
                            </span>
                            @enderror
                        </div>
                        <div class="mb-3">
                            <label for="is_active" class="form-label">{{ __('messages.status') }}</label>
                            <select name="is_active" id="is_active" class="form-control">
                                <option value="1" {{ $area->is_active == 1 ? 'selected' : '' }}>{{ __('messages.active') }}</option>
                                <option value="0" {{ $area->is_active == 0 ? 'selected' : '' }}>{{ __('messages.inactive') }}</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary">{{ __('messages.update') }}</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
@endsection
