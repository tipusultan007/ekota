@extends('layout.master')
@push('plugin-styles')
    <link rel="stylesheet" href="{{ asset('build/plugins/flatpickr/flatpickr.min.css') }}">
@endpush
@section('content')
    <nav class="page-breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="{{ route('dashboard') }}">{{__('messages.dashboard')}}</a></li>
            <li class="breadcrumb-item active" aria-current="page">{{ __('messages.savings_collection_history') }}</li>
        </ol>
    </nav>


    <div class="row">
        <div class="col-md-12 grid-margin stretch-card">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between align-items-center mb-4">
                        <h6 class="card-title">{{ __('messages.savings_collection_log') }}</h6>
                    
                    </div>
                    <!-- Date Range Filter Form -->
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <form method="GET" action="{{ route('savings-collections.index') }}" class="row g-3 align-items-end">
                                <div class="col-md-3">
                                    <label for="start_date" class="form-label">{{ __('messages.start_date') }}</label>
                                    <input type="text" class="form-control flatpickr" id="start_date" name="start_date"
                                           value="{{ request('start_date') }}">
                                </div>
                                <div class="col-md-3">
                                    <label for="end_date" class="form-label">{{ __('messages.end_date') }}</label>
                                    <input type="text" class="form-control flatpickr" id="end_date" name="end_date"
                                           value="{{ request('end_date') }}">
                                </div>
                                <div class="col-md-3">
                                    <button type="submit" class="btn btn-primary">{{ __('messages.filter') }}</button>
                                    <a href="{{ route('savings-collections.index') }}" class="btn btn-secondary">{{ __('messages.reset') }}</a>
                                </div>
                                @if(request()->has('start_date') || request()->has('end_date'))
                                    <div class="col-md-3 text-end">
                                    <span class="text-muted">
                                        {{ __('messages.filtered_results') }}
                                    </span>
                                    </div>
                                @endif
                            </form>
                        </div>
                    </div>

                    @if (session('success'))
                        <div class="alert alert-success" role="alert">
                            {{ session('success') }}
                        </div>
                    @endif

                    <div class="table-responsive">
                        <table class="table table-hover">
                            <thead>
                            <tr>
                                <th>{{ __('messages.name') }}</th>
                                <th>{{ __('messages.account_no') }}</th>
                                <th>{{ __('messages.amount') }} (BDT)</th>
                                <th>{{ __('messages.collection_date') }}</th>
                                <th>{{ __('messages.collected_by') }}</th>
                                @role('Admin')<th>{{ __('messages.actions') }}</th>@endrole
                            </tr>
                            </thead>
                            <tbody>
                            @forelse ($collections as $collection)
                                <tr>
                                    <td>
                                        <a href="{{ route('members.show', $collection->member_id) }}">{{ $collection->member->name }}</a>
                                    </td>
                                    <td>{{ $collection->savingsAccount->account_no }}</td>
                                    <td class="text-end">{{ number_format($collection->amount, 2) }}</td>
                                    <td>{{ $collection->collection_date->format('d M, Y') }}</td>
                                    <td>{{ $collection->collector->name }}</td>
                                    @role('Admin')
                                    <td>
                                        <a href="{{ route('savings-collections.edit', $collection->id) }}" class="btn btn-primary btn-xs">{{ __('messages.edit') }}</a>
                                        <form action="{{ route('savings-collections.destroy', $collection->id) }}" method="POST" class="d-inline" onsubmit="return confirm('Are you sure?');">
                                            @csrf @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-xs">{{ __('messages.delete') }}</button>
                                        </form>
                                    </td>
                                    @endrole
                                </tr>
                            @empty
                                <tr>
                                    <td colspan="6" class="text-center">{{ __('messages.no_savings_collections_found') }}</td>
                                </tr>
                            @endforelse
                            </tbody>
                        </table>

                        <div class="mt-4">
                            {{ $collections->appends(request()->query())->links() }}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection
@push('custom-scripts')
    <script src="{{ asset('build/plugins/jquery/jquery.min.js') }}"></script>
    <script src="{{ asset('build/plugins/flatpickr/flatpickr.min.js') }}"></script>
    <script>
        $(".flatpickr").flatpickr({
            altInput: true,
            dateFormat: 'Y-m-d',
            altFormat: 'd/m/Y'
        })
    </script>
@endpush
